"""Compiled shader profiles: static-state G-buffer formulas translated into Blender nodes.

shader_profiles.json is produced offline from the game's own compiled pixel programs (v293
shader database, DXC disassembly, symbolic evaluation at shader defaults). It contains formulas
only. This module:
  1. matches a restored source material to a profile by exact shader identity,
  2. verifies every folded assumption against the actual material (parameters, bound textures),
  3. specializes the formulas with the material's own parameter values,
  4. emits Blender nodes and connects a Principled BSDF.
Unknown inputs fail closed: the slot stays unconnected and the reason is reported.
"""
import hashlib
import json
import math
from pathlib import Path

VERSION = "0.6.1"
_PROFILES = None
# Runtime vehicle customization -> shader parameter, by parameter-key equality (see SHADER-FINDINGS).
# RaceVehicleCustomizationComponentData key field -> (RaceVehicleItemData field, component fallback field).
RUNTIME_PAINT = {"PaintFacingColorParameter": ("DefaultPaint", "DefaultPaint"),
                 "PaintMaterialParameter": ("Material", "DefaultMaterial"),
                 "WindowsTintParameter": ("WindowsTint", "DefaultWindowsTint")}
OMITTED_REASON = "Output needs engine constants outside the shader database (e.g. exposure/day-night view constants); omitted"
UNSUPPORTED_OUTPUTS = {
    "RT1.w": "G-buffer occlusion/specular-occlusion term (vertex color ambient treatment) has no Principled input",
    "RT2.z": "G-buffer diffuse occlusion term has no Principled input",
    "RT4Color": "Car-paint second-layer color in the fifth G-buffer target; its deferred-lighting use is unknown",
}


def profiles():
    global _PROFILES
    if _PROFILES is None:
        _PROFILES = json.loads(Path(__file__).with_name("shader_profiles.json").read_text(encoding="utf-8"))
    return _PROFILES


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def profile_for(state):
    asset = ((state.get("Shader") or {}).get("Asset") or "").casefold()
    for name, p in profiles()["Profiles"].items():
        if name.casefold() == asset:
            return p
    return None


# ------------------------------------------------------------------ runtime vehicle inputs
def runtime_values(assembly_path):
    """{parameter key: [x, y, z, w?]} from RaceVehicleCustomizationComponentData keys and RaceVehicleItemData values."""
    if not assembly_path or not Path(assembly_path).is_file():
        return {}, ["assembly.json not found; runtime paint unavailable"], None
    doc = json.loads(Path(assembly_path).read_text(encoding="utf-8-sig"))
    raws = [n.get("Raw", {}) for n in doc.get("Nodes", [])]
    comps = [r for r in raws if r.get("Type") == "RaceVehicleCustomizationComponentData"]
    items = [r for r in raws if r.get("Type") == "RaceVehicleItemData"]
    notes, out = [], {}
    if len(comps) != 1:
        return {}, ["Expected one RaceVehicleCustomizationComponentData, found %d" % len(comps)], doc
    for field, (item_field, fallback) in RUNTIME_PAINT.items():
        key = ((comps[0].get(field) or {}).get("ShaderParameterHandle") or {}).get("Data")
        if not key:
            continue
        source = items[0].get(item_field) if len(items) == 1 else None
        origin = "RaceVehicleItemData." + item_field
        if not isinstance(source, dict):
            source = comps[0].get(fallback)
            origin = "RaceVehicleCustomizationComponentData." + fallback
            notes.append(field + ": no unique RaceVehicleItemData value; component default used")
        if isinstance(source, dict):
            out[key.casefold()] = {"Value": [float(source.get(c, 0.0)) for c in "xyz"], "Origin": origin, "Field": field}
    # Wheel customization: (Front|Rear)(Rim|Caliper)(Primary|Secondary)(Color|Material)Parameter keys take the
    # default item of that type and location (RimsItemData / CalipersItemData Primary/SecondaryPaint|Material).
    import re
    for field, value in comps[0].items():
        m = re.fullmatch(r"(Front|Rear)(Rim|Caliper)(Primary|Secondary)(Color|Material)Parameter", field)
        key = ((value or {}).get("ShaderParameterHandle") or {}).get("Data") if isinstance(value, dict) else None
        if not m or not key:
            continue
        kind = {"Rim": "RimsItemData", "Caliper": "CalipersItemData"}[m.group(2)]
        loc = "ItemPosition_" + m.group(1)
        items_here = [i for i in doc.get("Items", []) if i.get("Type") == kind and i.get("Default")
                      and ((i.get("Raw") or {}).get("Location") or {}).get("Name") == loc]
        item_field = m.group(3) + ("Paint" if m.group(4) == "Color" else "Material")
        if len(items_here) != 1 or not isinstance(items_here[0]["Raw"].get(item_field), dict):
            notes.append("%s: %d default %s at %s; not applied" % (field, len(items_here), kind, loc))
            continue
        v = items_here[0]["Raw"][item_field]
        out[key.casefold()] = {"Value": [float(v.get(c, 0.0)) for c in "xyz"], "Field": field,
                               "Origin": "%s %s.%s" % (kind, items_here[0].get("Asset", "").rsplit("/", 1)[-1], item_field)}
    return out, notes, doc


# ------------------------------------------------------------------ specialization
def _f(v):
    return float(v) if not isinstance(v, bool) else (1.0 if v else 0.0)


def _fold(op, a):
    """Scalar semantics for constant arguments (booleans as Python bool, integers as int)."""
    try:
        if op == "add": return a[0] + a[1]
        if op == "sub": return a[0] - a[1]
        if op == "mul": return a[0] * a[1]
        if op == "div": return a[0] / a[1] if a[1] != 0 else (math.copysign(math.inf, a[0]) if a[0] else math.nan)
        if op == "neg": return -a[0]
        if op == "max": return max(a[0], a[1])
        if op == "min": return min(a[0], a[1])
        if op == "abs": return abs(a[0])
        if op == "saturate": return min(max(a[0], 0.0), 1.0)
        if op == "sqrt": return math.sqrt(a[0]) if a[0] >= 0 else math.nan
        if op == "rsqrt": return 1 / math.sqrt(a[0]) if a[0] > 0 else math.inf
        if op == "exp2": return 2.0 ** a[0]
        if op == "log2": return math.log2(a[0]) if a[0] > 0 else -math.inf
        if op == "frac": return a[0] - math.floor(a[0])
        if op == "floor": return float(math.floor(a[0]))
        if op == "ceil": return float(math.ceil(a[0]))
        if op == "trunc": return float(math.trunc(a[0]))
        if op == "round_ne": return float(round(a[0]))
        if op in ("sin", "cos", "tan", "acos", "asin", "atan"): return getattr(math, op)(a[0])
        if op == "fmod": return math.fmod(a[0], a[1])
        if op == "select": return a[1] if a[0] else a[2]
        if op == "and": return bool(a[0]) and bool(a[1])
        if op == "or": return bool(a[0]) or bool(a[1])
        if op == "not": return not a[0]
        if op == "xor": return bool(a[0]) != bool(a[1])
        if op.startswith("fcmp_") or op.startswith("icmp_"):
            p = op[5:]
            x, y = a
            return {"oeq": x == y, "ueq": x == y, "one": x != y, "une": x != y, "eq": x == y, "ne": x != y,
                    "olt": x < y, "ult": x < y, "slt": x < y, "ole": x <= y, "ule": x <= y, "sle": x <= y,
                    "ogt": x > y, "ugt": x > y, "sgt": x > y, "oge": x >= y, "uge": x >= y, "sge": x >= y}[p]
        if op in ("fptoui_i32", "fptosi_i32"): return int(math.trunc(a[0])) if math.isfinite(a[0]) else 0
        if op in ("uitofp_float", "sitofp_float", "zext_i32"): return float(a[0]) if op != "zext_i32" else int(a[0])
        if op in ("iadd", "isub", "imul", "iand", "ior", "ishl", "ilshr", "isrem"):
            x, y = int(a[0]), int(a[1])
            return {"iadd": x + y, "isub": x - y, "imul": x * y, "iand": x & y, "ior": x | y,
                    "ishl": x << (y & 31), "ilshr": (x & 0xffffffff) >> (y & 31),
                    "isrem": int(math.fmod(x, y)) if y else 0}[op]
        if op == "binop37": return max(int(a[0]), int(a[1]))
        if op == "binop38": return min(int(a[0]), int(a[1]))
    except (ValueError, OverflowError, ZeroDivisionError):
        return math.nan
    return None


class Spec:
    """Profile nodes specialized to concrete parameter values; live parameters stay symbolic."""

    def __init__(self, profile, values, live, input_consts=None):
        self.profile, self.nodes, self.map = profile, [], {}
        self.input_consts = input_consts or {}
        for i, n in enumerate(profile["Nodes"]):
            self.map[i] = self._node(n, values, live)

    def ref(self, r):
        if "n" in r: return self.map[r["n"]]
        if "c" in r: return r["c"]
        if "i" in r: return r["i"]
        if "b" in r: return r["b"]
        raise ValueError(r)

    def _new(self, rec):
        self.nodes.append(rec)
        return ("N", len(self.nodes) - 1)

    def _node(self, n, values, live):
        op = n["op"]
        if op == "param":
            key = (n["name"], n["c"])
            if key in live:
                return self._new({"op": "param", "name": n["name"], "c": n["c"]})
            v = values[key]
            return int(v) if n.get("int") else float(v)
        if op in ("input", "view"):
            if n.get("name") in self.input_consts:
                return float(self.input_consts[n["name"]])
            return self._new(dict(n))
        if op == "tex":
            return self._new({"op": "tex", "slot": n["slot"], "kind": n["kind"],
                              "coords": [self.ref(c) for c in n["coords"]]})
        if op == "ch":
            return self._new({"op": "ch", "args": [self.ref(n["args"][0]), n["args"][1]["i"]]})
        if op == "frame":
            args = [self.ref(c) for c in n["args"]]
            if all(not isinstance(a, tuple) for a in args) and _f(args[0]) == 0 and _f(args[1]) == 0:
                # The frame's third column is the vertex normal interpolant itself: frame((0,0,c), k) = c * N_k.
                normal = self._new({"op": "input", "name": "WorldNormal." + "xyz"[n["k"]]})
                return normal if _f(args[2]) == 1 else self._new({"op": "mul", "args": [_f(args[2]), normal]})
            return self._new({"op": "frame", "args": args, "k": n["k"]})
        if op == "lookup":
            idx = self.ref(n["args"][0])
            if not isinstance(idx, tuple):
                table = n["table"]
                return table[max(0, min(len(table) - 1, int(idx)))]
            return self._new({"op": "lookup", "table": n["table"], "args": [idx]})
        args = [self.ref(a) for a in n["args"]]
        if all(not isinstance(a, tuple) for a in args):
            r = _fold(op, args)
            if r is not None:
                return r
        # Light algebraic simplification with constants (same rules as the offline simplifier).
        if op == "select" and not isinstance(args[0], tuple):
            return args[1] if args[0] else args[2]
        if op == "select" and args[1] == args[2] and not isinstance(args[1], tuple):
            return args[1]
        if op == "mul" and any(not isinstance(a, tuple) and a == 0 for a in args):
            return 0.0
        if op == "mul" and not isinstance(args[0], tuple) and args[0] == 1: return args[1]
        if op == "mul" and not isinstance(args[1], tuple) and args[1] == 1: return args[0]
        if op == "add" and not isinstance(args[0], tuple) and args[0] == 0: return args[1]
        if op == "add" and not isinstance(args[1], tuple) and args[1] == 0: return args[0]
        if op == "sub" and not isinstance(args[1], tuple) and args[1] == 0: return args[0]
        if op == "and":
            if any(a is False for a in args): return False
            if args[0] is True: return args[1]
            if args[1] is True: return args[0]
        if op == "or":
            if any(a is True for a in args): return True
            if args[0] is False: return args[1]
            if args[1] is False: return args[0]
        return self._new({"op": op, "args": args})

    def output(self, name):
        o = self.profile["Outputs"].get(name)
        if o is None:
            return None
        return [self.ref(r) for r in o] if isinstance(o, list) else self.ref(o)


# ------------------------------------------------------------------ verification of folded assumptions
def parameter_values(profile, state, runtime):
    """Concrete values for every external parameter, with fail-closed checks for non-exposed overrides."""
    by_name = {}
    for p in state["Parameters"].get("VectorParameters", {}).values():
        name = p.get("ParameterName")
        name = name.get("Value") if isinstance(name, dict) else name
        value = p.get("Value", {})
        if isinstance(value, dict):
            by_name[name.casefold()] = [float(value.get(c, 0.0)) for c in "xyzw"]
    for p in state["Parameters"].get("BoolParameters", {}).values():
        name = p.get("ParameterName")
        name = name.get("Value") if isinstance(name, dict) else name
        by_name[name.casefold()] = [1.0 if p.get("Value") else 0.0] * 4
    values, applied, issues = {}, [], []
    static = profile.get("StaticOverrides", {})
    for e in profile["Externals"]:
        default = list(static.get(e["Name"], e["Default"]))
        if e["Type"] == 1 and e["Name"] not in static:
            default = [float(int.from_bytes(__import__("struct").pack("<f", x), "little")) for x in default]
        v = by_name.get(e["Name"].casefold(), default)
        rt = runtime.get(e["Key"].casefold())
        if rt:
            v = rt["Value"] + default[len(rt["Value"]):]
            applied.append({"Parameter": e["Name"], "Value": v, "Origin": rt["Origin"],
                            "Precedence": "runtime vehicle parameter overrides material value"
                            if e["Name"].casefold() in by_name else "runtime vehicle parameter"})
        elif not e["Exposed"] and any(abs(a - b) > 1e-6 for a, b in zip(v, default)):
            issues.append("Parameter %s differs from the profile's folded default" % e["Name"])
        for c in range(4):
            values[(e["Name"], c)] = v[c]
    return values, applied, issues


def check_bindings(profile, state, root, image_loader):
    """Folded texture slots must match the actual binding; returns {slot: image source} for sampled slots."""
    bindings = {b["Parameter"].casefold(): b for b in state["TextureBindings"]}
    issues, sources = [], {}
    built = {k.casefold(): v for k, v in profile.get("BoundAtProfileBuild", {}).items()}
    for k, v in built.items():
        if v == "image" or k not in bindings:
            continue
        b = bindings[k]
        try:
            uniform = image_loader.uniform(root, b)
        except Exception as exc:
            issues.append("Cannot verify folded texture %s: %s" % (b["Parameter"], exc))
            continue
        if uniform is None or any(abs(a - c) > 1.5 / 255 for a, c in zip(uniform, v)):
            issues.append("Texture %s is not the uniform value the profile folded" % b["Parameter"])
    for slot, info in profile["Slots"].items():
        p = (info.get("Parameter") or "").casefold()
        if p and p in bindings:
            sources[int(slot)] = ("binding", bindings[p])
        elif info.get("DefaultAsset"):
            sources[int(slot)] = ("default", info["DefaultAsset"])
        else:
            issues.append("Texture slot t%s has no binding or shader default" % slot)
        if info.get("Dim") not in ("2d", "2darray"):
            sources[int(slot)] = ("unsupported", "%s texture (%s)" % (info.get("Dim"), info.get("DefaultAsset") or p))
    return sources, issues


# ------------------------------------------------------------------ Blender node emission
MATH = {"add": "ADD", "sub": "SUBTRACT", "mul": "MULTIPLY", "div": "DIVIDE", "max": "MAXIMUM", "min": "MINIMUM",
        "abs": "ABSOLUTE", "sqrt": "SQRT", "rsqrt": "INVERSE_SQRT", "frac": "FRACT", "floor": "FLOOR",
        "ceil": "CEIL", "trunc": "TRUNC", "round_ne": "ROUND", "sin": "SINE", "cos": "COSINE", "tan": "TANGENT",
        "acos": "ARCCOSINE", "asin": "ARCSINE", "atan": "ARCTANGENT", "fmod": "MODULO", "isrem": "MODULO",
        "iadd": "ADD", "isub": "SUBTRACT", "imul": "MULTIPLY", "binop37": "MAXIMUM", "binop38": "MINIMUM",
        "fptoui_i32": "TRUNC", "fptosi_i32": "TRUNC"}
IDENTITY = {"uitofp_float", "sitofp_float", "zext_i32"}


class Unsupported(Exception):
    pass


class NodeBuilder:
    """Emit one specialized profile into a node tree. Values are Python numbers or output sockets."""

    def __init__(self, tree, spec, ctx):
        self.t, self.spec, self.ctx = tree, spec, ctx
        self.memo, self.shared, self.column = {}, {}, {}

    # -- primitives
    def _place(self, node, depth):
        y = self.column.get(depth, 0)
        node.location = (-2400 + depth * 170, 1200 - y)
        self.column[depth] = y + 150

    def _set(self, sock, v):
        if isinstance(v, (bool, int, float)):
            sock.default_value = _f(v)
        else:
            self.t.links.new(v, sock)

    def math(self, operation, a, b=None, c=None, clamp=False, depth=10, label=""):
        n = self.t.nodes.new("ShaderNodeMath")
        n.operation, n.use_clamp = operation, clamp
        if label:
            n.label = label
        for i, v in enumerate((a, b, c)):
            if v is not None:
                self._set(n.inputs[i], v)
        self._place(n, depth)
        return n.outputs[0]

    def separate(self, vec_socket, key, depth=2):
        if key not in self.shared:
            n = self.t.nodes.new("ShaderNodeSeparateXYZ")
            self.t.links.new(vec_socket, n.inputs[0])
            self._place(n, depth)
            self.shared[key] = n
        return self.shared[key]

    def combine(self, xyz, depth=12):
        n = self.t.nodes.new("ShaderNodeCombineXYZ")
        for s, v in zip(n.inputs, xyz):
            self._set(s, v)
        self._place(n, depth)
        return n.outputs[0]

    def shared_node(self, key, kind, setup=None, depth=0):
        if key not in self.shared:
            n = self.t.nodes.new(kind)
            if setup:
                setup(n)
            self._place(n, depth)
            self.shared[key] = n
        return self.shared[key]

    # -- Frostbite <-> Blender axes (from the assembly's recorded FBX conversion)
    def to_fb(self, vec_socket, key):
        """Blender world vector -> Frostbite world components (x, y, z)."""
        if ("fb", key) in self.shared:
            return self.shared[("fb", key)]
        out = []
        for row in self.ctx["blender_to_fb"]:
            n = self.t.nodes.new("ShaderNodeVectorMath")
            n.operation = "DOT_PRODUCT"
            self.t.links.new(vec_socket, n.inputs[0])
            n.inputs[1].default_value = row
            self._place(n, 1)
            out.append(n.outputs["Value"])
        self.shared[("fb", key)] = out
        return out

    def to_blender(self, xyz):
        v = self.combine(xyz, depth=29)
        out = []
        for row in self.ctx["fb_to_blender"]:
            n = self.t.nodes.new("ShaderNodeVectorMath")
            n.operation = "DOT_PRODUCT"
            self.t.links.new(v, n.inputs[0])
            n.inputs[1].default_value = row
            self._place(n, 30)
            out.append(n.outputs["Value"])
        return self.combine(out, depth=31)

    def srgb_encode(self, lin, key):
        """Recover the source UByte4N value from Blender's byte-colour (sRGB-decoded) attribute.

        Inverse sRGB transfer, then snap to the nearest k/255: the source is exactly k/255, and the
        decode/encode round trip error (~5e-5) is far below half a step, so the snap is lossless."""
        if ("enc", key) in self.shared:
            return self.shared[("enc", key)]
        low = self.math("MULTIPLY", lin, 12.92, depth=2)
        p = self.math("POWER", lin, 1 / 2.4, depth=2)
        high = self.math("MULTIPLY_ADD", p, 1.055, -0.055, depth=3)
        is_low = self.math("LESS_THAN", lin, 0.0031308, depth=2)
        r = self.mix(is_low, low, high, depth=4)
        r = self.math("DIVIDE", self.math("ROUND", self.math("MULTIPLY", r, 255.0, depth=5), depth=5), 255.0, depth=6,
                      label="Snap to source byte k/255")
        self.shared[("enc", key)] = r
        return r

    def mix(self, cond, a_true, b_false, depth=20):
        if not isinstance(a_true, (bool, int, float)) or not isinstance(b_false, (bool, int, float)):
            n = self.t.nodes.new("ShaderNodeMix")
            n.data_type, n.clamp_factor = "FLOAT", True
            self._set(n.inputs["Factor"], cond)
            self._set(n.inputs[2], b_false)   # A (factor 0)
            self._set(n.inputs[3], a_true)    # B (factor 1)
            self._place(n, depth)
            return n.outputs[0]
        return self.math("MULTIPLY_ADD", cond, _f(a_true) - _f(b_false), _f(b_false), depth=depth)

    # -- leaves
    def input(self, name):
        ctx = self.ctx
        if name.startswith("Const:"):
            return float(name.split(":", 1)[1])
        if name == "ViewFade":
            # Vertex-program fade from runtime view constants (camera environment): static state = no attenuation.
            note = "Assumption: per-vertex view fade (vertex-program polynomial of runtime view constants) = 1"
            if note not in ctx.setdefault("notes", []):
                ctx["notes"].append(note)
            return 1.0
        kind, _, comp = name.partition(".")
        if kind.startswith("TexCoord"):
            layer = ctx["uv"].get(kind)
            if not layer:
                raise Unsupported("Source %s has no Blender UV layer provenance" % kind)
            uv = self.shared_node(("uv", layer), "ShaderNodeUVMap", lambda n: setattr(n, "uv_map", layer))
            sep = self.separate(uv.outputs["UV"], ("uvsep", layer))
            if comp == "u":
                return sep.outputs["X"]
            if ("v", layer) not in self.shared:
                self.shared[("v", layer)] = self.math("SUBTRACT", 1.0, sep.outputs["Y"], depth=3,
                                                      label="Source V = 1 - Blender V (Frosty export flip)")
            return self.shared[("v", layer)]
        if kind.startswith("Color"):
            attr = ctx["colors"].get(kind)
            if not attr:
                raise Unsupported("Source %s has no Blender color attribute provenance" % kind)
            node = self.shared_node(("col", attr["name"]), "ShaderNodeVertexColor",
                                    lambda n: setattr(n, "layer_name", attr["name"]))
            if comp == "a":
                return node.outputs["Alpha"]
            sep = self.shared_node(("colsep", attr["name"]), "ShaderNodeSeparateColor", depth=1)
            if not sep.inputs[0].is_linked:
                self.t.links.new(node.outputs["Color"], sep.inputs[0])
            ch = sep.outputs["rgb".index(comp)]
            return self.srgb_encode(ch, (attr["name"], comp)) if attr["byte"] else ch
        if kind == "WorldPos":
            g = self.shared_node("geo", "ShaderNodeNewGeometry")
            return self.to_fb(g.outputs["Position"], "pos")["xyz".index(comp)]
        if kind == "WorldNormal":
            g = self.shared_node("geo", "ShaderNodeNewGeometry")
            return self.to_fb(g.outputs["Normal"], "normal")["xyz".index(comp)]
        if kind == "ObjectPos":
            tc = self.shared_node("texco", "ShaderNodeTexCoord")
            return self.separate(tc.outputs["Object"], "objsep").outputs["xyz".index(comp)]
        if kind == "ObjectOrigin":
            oi = self.shared_node("objinfo", "ShaderNodeObjectInfo")
            return self.to_fb(oi.outputs["Location"], "origin")["xyz".index(comp)]
        raise Unsupported("Unresolved shader input " + name)

    def view(self, name):
        if name == "Time":
            return 0.0  # static state
        if name.startswith("CameraPos."):
            if "campos" not in self.shared:
                g = self.shared_node("geo", "ShaderNodeNewGeometry")
                cam = self.shared_node("camdata", "ShaderNodeCameraData")
                scale = self.t.nodes.new("ShaderNodeVectorMath")
                scale.operation = "SCALE"
                self.t.links.new(g.outputs["Incoming"], scale.inputs[0])
                self.t.links.new(cam.outputs["View Distance"], scale.inputs["Scale"])
                add = self.t.nodes.new("ShaderNodeVectorMath")
                add.operation = "ADD"
                add.label = "Camera position = P + incoming * view distance"
                self.t.links.new(g.outputs["Position"], add.inputs[0])
                self.t.links.new(scale.outputs["Vector"], add.inputs[1])
                self._place(scale, 1)
                self._place(add, 1)
                self.shared["campos"] = add.outputs["Vector"]
            return self.to_fb(self.shared["campos"], "campos")["xyz".index(name[-1])]
        raise Unsupported("Unresolved view constant " + name)

    def texture(self, idx, rec):
        if ("tex", idx) in self.memo:
            return self.memo[("tex", idx)]
        image = self.ctx["images"].get(rec["slot"])
        if image is None:
            raise Unsupported("Texture slot t%d unavailable: %s" % (rec["slot"], self.ctx["image_issues"].get(rec["slot"], "")))
        coords = [self.value(c) for c in rec["coords"]]
        if isinstance(image, list):
            if len(coords) != 3:
                raise Unsupported("Array texture t%d sampled without a layer" % rec["slot"])
            out = self._array_sample(rec, image, coords)
            self.memo[("tex", idx)] = out
            return out
        if len(coords) != 2:
            raise Unsupported("Non-2D sample on t%d" % rec["slot"])
        out = self._sample(rec["slot"], image, coords)
        self.memo[("tex", idx)] = out
        return out

    def _array_sample(self, rec, images, coords):
        """D3D Texture2DArray: layer = clamp(round(z), 0, count - 1)."""
        layer = coords[2]
        if isinstance(layer, (int, float)):
            i = max(0, min(len(images) - 1, int(math.floor(layer + 0.5))))
            return self._sample(rec["slot"], images[i], coords[:2])
        layer = self.math("ROUND", layer, depth=13)
        result = None
        for i, image in enumerate(images):
            sample = self._sample(rec["slot"], image, coords[:2])
            if result is None:
                result = sample
                continue
            pick = self.math("COMPARE", layer, float(i), 0.5, depth=18) if i < len(images) - 1 else                 self.math("GREATER_THAN", layer, float(i) - 0.5, depth=18)
            result = [self.mix(pick, s, r, depth=19) for s, r in zip(sample, result)]
        return result

    def _sample(self, slot, image, coords):
        flipped = self.math("SUBTRACT", 1.0, coords[1], depth=14, label="Game V -> Blender V")
        vec = self.combine([coords[0], flipped, 0.0], depth=15)
        n = self.t.nodes.new("ShaderNodeTexImage")
        n.image, n.extension, n.interpolation = image, "REPEAT", "Linear"
        n.label = "t%d %s" % (slot, image.get("unbound_asset", image.name))
        self.t.links.new(vec, n.inputs["Vector"])
        self._place(n, 16)
        sep = self.t.nodes.new("ShaderNodeSeparateColor")
        self.t.links.new(n.outputs["Color"], sep.inputs[0])
        self._place(sep, 17)
        return [sep.outputs[0], sep.outputs[1], sep.outputs[2], n.outputs["Alpha"]]

    def frame(self, rec):
        """frame(v, k): component k of T*v.x + B*v.y + N*v.z in Frostbite world, via a Normal Map node."""
        fkey = ("framevec", tuple(map(str, rec["args"])))
        if fkey not in self.shared:
            signs = self.ctx.get("basis_signs")
            if not signs:
                # Unverified basis: keep only the normal-aligned term (tangent-plane detail disabled, reported).
                self.ctx.setdefault("notes", []).append("Tangent-space detail disabled: " + self.ctx.get("basis_reason", "basis unverified"))
                g = self.shared_node("geo", "ShaderNodeNewGeometry")
                n = self.to_fb(g.outputs["Normal"], "normal")
                self.shared[fkey] = [self.math("MULTIPLY", n[k], self.value(rec["args"][2])) for k in range(3)]
                return self.shared[fkey][rec["k"]]
            v = self.combine([self.value(a) for a in rec["args"]], depth=20)
            length = self.t.nodes.new("ShaderNodeVectorMath")
            length.operation = "LENGTH"
            self.t.links.new(v, length.inputs[0])
            norm = self.t.nodes.new("ShaderNodeVectorMath")
            norm.operation = "NORMALIZE"
            self.t.links.new(v, norm.inputs[0])
            scale = self.t.nodes.new("ShaderNodeVectorMath")
            scale.operation = "MULTIPLY"
            self.t.links.new(norm.outputs["Vector"], scale.inputs[0])
            scale.inputs[1].default_value = tuple(0.5 * s for s in signs)
            bias = self.t.nodes.new("ShaderNodeVectorMath")
            bias.operation = "ADD"
            self.t.links.new(scale.outputs["Vector"], bias.inputs[0])
            bias.inputs[1].default_value = (0.5, 0.5, 0.5)
            nm = self.t.nodes.new("ShaderNodeNormalMap")
            nm.space, nm.uv_map = "TANGENT", self.ctx["tangent_uv"]
            nm.label = "Source tangent frame (basis checked against this mesh's FBX)"
            self.t.links.new(bias.outputs["Vector"], nm.inputs["Color"])
            world = self.t.nodes.new("ShaderNodeVectorMath")
            world.operation = "SCALE"
            self.t.links.new(nm.outputs["Normal"], world.inputs[0])
            self.t.links.new(length.outputs["Value"], world.inputs["Scale"])
            for i, n in enumerate((length, norm, scale, bias, nm, world)):
                self._place(n, 21 + i)
            self.shared[fkey] = self.to_fb(world.outputs["Vector"], fkey)
        return self.shared[fkey][rec["k"]]

    # -- generic value
    def value(self, v):
        if not isinstance(v, tuple):
            return _f(v) if isinstance(v, bool) else v
        idx = v[1]
        if idx in self.memo:
            return self.memo[idx]
        rec = self.spec.nodes[idx]
        op = rec["op"]
        if op == "input":
            r = self.input(rec["name"])
        elif op == "view":
            r = self.view(rec["name"])
        elif op == "param":
            r = self.ctx["live"][(rec["name"], rec["c"])]
        elif op == "tex":
            r = self.texture(idx, rec)
        elif op == "ch":
            src = rec["args"][0]
            r = self.texture(src[1], self.spec.nodes[src[1]])[rec["args"][1]]
        elif op == "frame":
            r = self.frame(rec)
        elif op == "exp2" and self._pow_pattern(rec):
            base, k = self._pow_pattern(rec)
            r = self.math("POWER", self.value(base), self.value(k))
        else:
            r = self.operation(op, [self.value(a) for a in rec["args"]], rec)
        self.memo[idx] = r
        return r

    def _pow_pattern(self, rec):
        """exp2(k * log2(x)) -> (x, k). DXIL gives exp2(-inf) = 0 at x = 0; Blender POWER(0, k > 0) = 0 matches,
        while Blender's safe LOGARITHM would return 0 and turn the result into 1."""
        arg = rec["args"][0]
        inner = self.spec.nodes[arg[1]] if isinstance(arg, tuple) else None
        if inner and inner["op"] == "mul":
            for i in (0, 1):
                lg, other = inner["args"][i], inner["args"][1 - i]
                if isinstance(lg, tuple) and self.spec.nodes[lg[1]]["op"] == "log2":
                    return self.spec.nodes[lg[1]]["args"][0], other
        return None

    def operation(self, op, a, rec):
        if op in IDENTITY:
            return a[0]
        if op in MATH:
            return self.math(MATH[op], *a[:2]) if len(a) > 1 else self.math(MATH[op], a[0])
        if op == "neg":
            return self.math("MULTIPLY", a[0], -1.0)
        if op == "saturate":
            return self.math("ADD", a[0], 0.0, clamp=True)
        if op == "exp2":
            return self.math("POWER", 2.0, a[0])
        if op == "log2":
            return self.math("LOGARITHM", a[0], 2.0)
        if op in ("fcmp_olt", "fcmp_ult", "icmp_slt", "icmp_ult"):
            return self.math("LESS_THAN", a[0], a[1])
        if op in ("fcmp_ogt", "fcmp_ugt", "icmp_sgt", "icmp_ugt"):
            return self.math("GREATER_THAN", a[0], a[1])
        if op in ("fcmp_ole", "fcmp_ule", "icmp_sle", "icmp_ule"):
            return self.math("SUBTRACT", 1.0, self.math("GREATER_THAN", a[0], a[1]))
        if op in ("fcmp_oge", "fcmp_uge", "icmp_sge", "icmp_uge"):
            return self.math("SUBTRACT", 1.0, self.math("LESS_THAN", a[0], a[1]))
        if op in ("fcmp_oeq", "fcmp_ueq"):
            return self.math("COMPARE", a[0], a[1], 0.0)
        if op in ("fcmp_one", "fcmp_une"):
            return self.math("SUBTRACT", 1.0, self.math("COMPARE", a[0], a[1], 0.0))
        if op == "icmp_eq":
            return self.math("COMPARE", a[0], a[1], 0.5)
        if op == "icmp_ne":
            return self.math("SUBTRACT", 1.0, self.math("COMPARE", a[0], a[1], 0.5))
        if op == "and":
            return self.math("MULTIPLY", a[0], a[1])
        if op == "or":
            return self.math("MAXIMUM", a[0], a[1])
        if op == "not":
            return self.math("SUBTRACT", 1.0, a[0])
        if op == "xor":
            return self.math("ABSOLUTE", self.math("SUBTRACT", a[0], a[1]))
        if op == "select":
            return self.mix(a[0], a[1], a[2])
        if op == "ishl" and isinstance(a[1], (int, float)):
            return self.math("MULTIPLY", a[0], float(2 ** int(a[1])))
        if op == "ilshr" and isinstance(a[1], (int, float)):
            return self.math("FLOOR", self.math("DIVIDE", a[0], float(2 ** int(a[1]))))
        if op == "iand" and isinstance(a[1], (int, float)):
            mask = int(a[1]) & 0xffffffff
            if mask & (mask + 1) == 0:  # low-bit mask on non-negative integers
                return self.math("MODULO", a[0], float(mask + 1))
            if mask == 0xfffffffe:
                return self.math("SUBTRACT", a[0], self.math("MODULO", a[0], 2.0))
        if op == "lookup":
            r = 0.0
            for i, value in enumerate(rec["table"]):
                r = self.mix(self.math("COMPARE", a[0], float(i), 0.5), float(value), r)
            return r
        raise Unsupported("No node translation for operation " + op)


# ------------------------------------------------------------------ images
class Images:
    """Resolve export textures and shader-default textures (by source asset name) to Blender images."""

    def __init__(self, root, extra_folders=()):
        self.root = Path(root)
        self.by_asset, self.cache = {}, {}
        doc = json.loads((self.root / "materials.json").read_text(encoding="utf-8-sig"))
        textures = {t["ResourceId"]: t for t in doc.get("Textures", [])}
        for n in doc.get("Nodes", []):
            if n.get("Type") == "TextureAsset" and n.get("TextureResource") in textures:
                self.by_asset.setdefault(n["Asset"].casefold(), (self.root, textures[n["TextureResource"]]))
        for folder in (self.root / "shader-defaults", self.root.parent / "shader-defaults",
                       *[Path(f) for f in extra_folders if f]):
            index = folder / "textures.json"
            if index.is_file():
                for t in json.loads(index.read_text(encoding="utf-8-sig")).get("Textures", []):
                    for alias in t.get("Aliases", []):
                        if t.get("Path"):
                            self.by_asset.setdefault(alias["Asset"].casefold(), (folder, t))

    def _path(self, root, relative):
        path = (Path(root) / relative).resolve()
        if not path.is_relative_to(Path(root).resolve()):
            raise ValueError("Texture path escapes its export folder")
        if not path.is_file():
            raise FileNotFoundError(str(path))
        return path

    def load(self, root, record, asset=None):
        import bpy
        path = self._path(root, record["Path"])
        colorspace = "sRGB" if record.get("ColorSpace") == "sRGB" else "Non-Color"
        key = (str(path), colorspace)
        if key in self.cache:
            return self.cache[key]
        image = next((im for im in bpy.data.images if im.get("unbound_source_path") == str(path)
                      and im.colorspace_settings.name == colorspace and im.alpha_mode == "CHANNEL_PACKED"), None)
        if image is None:
            image = bpy.data.images.load(str(path), check_existing=False)
            image["unbound_resource_id"] = record.get("ResourceId", "")
            image["unbound_source_path"] = str(path)
            image["unbound_source_colorspace"] = record.get("ColorSpace", "unspecified")
            image["unbound_format"] = record.get("Format", "")
            image.colorspace_settings.name = colorspace
            image.alpha_mode = "CHANNEL_PACKED"
        if asset:
            image["unbound_asset"] = asset
        if image.size[0] == 0:
            raise ValueError("Blender could not decode " + path.name)
        self.cache[key] = image
        return image

    def resolve(self, source):
        """Image, or list of slice images for a 2D texture array."""
        kind, value = source
        if kind == "binding":
            return self.load(self.root, value, value.get("Asset"))
        if kind == "default":
            hit = self.by_asset.get(value.casefold())
            if not hit:
                raise FileNotFoundError("Shader default texture not exported: " + value)
            if hit[1].get("Slices"):
                return [self.load(hit[0], dict(hit[1], Path=s["Path"]), value + "[%d]" % i)
                        for i, s in enumerate(hit[1]["Slices"])]
            return self.load(hit[0], hit[1], value)
        raise ValueError(value)

    def uniform(self, root, binding):
        """Decoded uniform RGBA (shader-visible, sRGB linearized) or None."""
        import numpy as np
        image = self.load(root, binding, binding.get("Asset"))
        px = np.empty(image.size[0] * image.size[1] * 4, dtype=np.float32)
        image.pixels.foreach_get(px)
        px = px.reshape(-1, 4)
        if not np.all(np.abs(px - px[0]) < 1e-6):
            return None
        v = [float(x) for x in px[0]]
        if binding.get("ColorSpace") == "sRGB" and not image.is_float:
            v[:3] = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in v[:3]]
        return v


# ------------------------------------------------------------------ object context
def color_bindings(section):
    """Mirror Frosty FBXExporter: Color0/Color1 become VColor1/2 in declaration traversal order."""
    out, n = {}, 0
    for attr in sorted(section.get("VertexAttributes", []), key=lambda a: a.get("StreamIndex", 0)):
        if attr["Usage"] in ("Color0", "Color1") and attr["Usage"] not in out:
            n += 1
            out[attr["Usage"]] = "VColor%d" % n
    return out


def axis_matrices(obj):
    import bpy
    for c in bpy.data.collections:
        if c.get("fbx_to_blender_matrix") and obj.name in c.all_objects:
            m = json.loads(c["fbx_to_blender_matrix"])
            r = [row[:3] for row in m[:3]]
            break
    else:
        r = [[1, 0, 0], [0, 0, -1], [0, 1, 0]]  # Blender FBX importer Y-up -> Z-up default
    inv = [[r[j][i] for j in range(3)] for i in range(3)]  # rotation: inverse = transpose
    return [tuple(map(float, row)) for row in r], [tuple(map(float, row)) for row in inv]


def reachable(spec, outputs):
    seen, stack = set(), [v for v in outputs if isinstance(v, tuple)]
    while stack:
        v = stack.pop()
        if v[1] in seen:
            continue
        seen.add(v[1])
        rec = spec.nodes[v[1]]
        for a in rec.get("args", []) + rec.get("coords", []):
            if isinstance(a, tuple):
                stack.append(a)
            elif isinstance(a, list):
                stack.extend(x for x in a if isinstance(x, tuple))
    return seen


def is_geometric_normal(spec, comps):
    names = []
    for c in comps:
        if not isinstance(c, tuple) or spec.nodes[c[1]]["op"] != "input":
            return False
        names.append(spec.nodes[c[1]]["name"])
    return names == ["WorldNormal.x", "WorldNormal.y", "WorldNormal.z"]


def is_const(v, value=None):
    return not isinstance(v, tuple) and (value is None or _f(v) == value)


# ------------------------------------------------------------------ live runtime parameters
def live_group(name, value):
    """One shared, user-editable control per live runtime parameter (e.g. the vehicle paint)."""
    import bpy
    gname = "Unbound | Runtime " + name
    g = bpy.data.node_groups.get(gname)
    if g and g.get("unbound_live_parameter") == name:
        return g
    g = bpy.data.node_groups.new(gname, "ShaderNodeTree")
    g["unbound_live_parameter"] = name
    g["unbound_note"] = ("Runtime vehicle input. Initial value from the vehicle data; edit the RGB node to repaint. "
                         "Finish selectors are specialized at build time.")
    for c in "xyzw":
        g.interface.new_socket(name=c, in_out="OUTPUT", socket_type="NodeSocketFloat")
    out = g.nodes.new("NodeGroupOutput")
    out.location = (400, 0)
    rgb = g.nodes.new("ShaderNodeRGB")
    rgb.label = name + ".xyz (linear shader value)"
    rgb.outputs[0].default_value = (value[0], value[1], value[2], 1.0)
    w = g.nodes.new("ShaderNodeValue")
    w.label = name + ".w"
    w.outputs[0].default_value = value[3]
    w.location = (0, -200)
    sep = g.nodes.new("ShaderNodeSeparateColor")
    sep.location = (200, 0)
    g.links.new(rgb.outputs[0], sep.inputs[0])
    for i in range(3):
        g.links.new(sep.outputs[i], out.inputs[i])
    g.links.new(w.outputs[0], out.inputs[3])
    g.use_fake_user = True
    return g


# ------------------------------------------------------------------ build one slot
OUTPUT_SOCKETS = (("Base Color", "NodeSocketColor"), ("Metallic", "NodeSocketFloat"), ("Roughness", "NodeSocketFloat"),
                  ("Normal", "NodeSocketVector"), ("Coat Weight", "NodeSocketFloat"), ("Coat Roughness", "NodeSocketFloat"),
                  ("Coat Normal", "NodeSocketVector"), ("Emission Color", "NodeSocketColor"), ("Alpha", "NodeSocketFloat"))


def plan(profile, state, runtime, live_names, images, root, input_consts=None):
    """Everything that does not depend on the object's geometry: parameters, specialization, textures."""
    values, applied, issues = parameter_values(profile, state, runtime)
    live = {(n, c) for n in live_names for c in range(4)
            if any(a["Parameter"] == n for a in applied)}
    spec = Spec(profile, values, live, input_consts)
    sources, bind_issues = check_bindings(profile, state, root, images)
    issues += bind_issues
    outs = {k: spec.output(k) for k in profile["Outputs"]}
    used = reachable(spec, [x for v in outs.values() for x in (v if isinstance(v, list) else [v])])
    used_slots = {spec.nodes[i]["slot"] for i in used if spec.nodes[i]["op"] == "tex"}
    image_map, image_issues = {}, {}
    for slot in used_slots:
        src = sources.get(slot)
        try:
            if not src or src[0] == "unsupported":
                raise ValueError(src[1] if src else "no source")
            image_map[slot] = images.resolve(src)
        except Exception as exc:
            image_issues[slot] = str(exc)
    uses_frame = any(spec.nodes[i]["op"] == "frame" for i in used)
    inputs = sorted({spec.nodes[i]["name"] for i in used if spec.nodes[i]["op"] in ("input", "view")})
    return {"values": values, "applied": applied, "issues": issues, "spec": spec, "outs": outs,
            "input_consts": dict(input_consts or {}),
            "images": image_map, "image_issues": image_issues, "uses_frame": uses_frame, "inputs": inputs,
            "live": live}


def build_group(profile, p, ctx, identity, label):
    import bpy
    existing = next((g for g in bpy.data.node_groups if g.get("unbound_profile_identity") == identity), None)
    if existing:
        return existing, json.loads(existing["unbound_connected_json"])
    g = bpy.data.node_groups.new(label, "ShaderNodeTree")
    try:
        g["unbound_profile_identity"] = identity
        spec, outs = p["spec"], p["outs"]
        b = NodeBuilder(g, spec, dict(ctx, images=p["images"], image_issues=p["image_issues"]))
        live_nodes = {}
        for (name, c) in p["live"]:
            if name not in live_nodes:
                n = g.nodes.new("ShaderNodeGroup")
                n.node_tree = live_group(name, [p["values"][(name, k)] for k in range(4)])
                n.label = "Runtime vehicle input: " + name
                n.location = (-2600, 1400)
                live_nodes[name] = n
            b.ctx.setdefault("live", {})[(name, c)] = live_nodes[name].outputs[c]
        connected, results = [], {}
        if profile.get("Kind") == "forward_transmittance":
            results["Transmittance"] = b.combine([b.value(x) for x in outs["Transmittance"]], depth=32)
            if "Reflectance" in outs:
                results["Reflectance"] = b.math("ADD", b.value(outs["Reflectance"]), 0.0, clamp=True, depth=32,
                                                label="1 - common transmittance factor (program's Fresnel term)")
            return _finish_group(g, results, connected, (("Transmittance", "NodeSocketColor"), ("Reflectance", "NodeSocketFloat")))
        results["Base Color"] = b.combine([b.value(x) for x in outs["BaseColor"]], depth=32)
        results["Metallic"] = b.value(outs["Metallic"])
        results["Roughness"] = b.math("SUBTRACT", 1.0, b.math("ADD", b.value(outs["Smoothness"]), 0.0, clamp=True, depth=32),
                                      depth=33, label="Principled roughness = 1 - source smoothness")
        if not is_geometric_normal(spec, outs["Normal"]):
            results["Normal"] = b.to_blender([b.value(x) for x in outs["Normal"]])
        if "CoatSmoothness" in outs:
            results["Coat Weight"] = b.math("ADD", b.value(outs["RT2.x"]), 0.0, clamp=True, depth=32,
                                            label="RT2.x (fifth-target layout): interpreted as clear-coat weight")
            results["Coat Roughness"] = b.math("SUBTRACT", 1.0, b.math("ADD", b.value(outs["CoatSmoothness"]), 0.0, clamp=True, depth=32), depth=33)
            if "CoatNormal" in outs and not is_geometric_normal(spec, outs["CoatNormal"]):
                results["Coat Normal"] = b.to_blender([b.value(x) for x in outs["CoatNormal"]])
        if "Emissive" in outs and not all(is_const(x, 0.0) for x in outs["Emissive"]):
            results["Emission Color"] = b.combine([b.value(x) for x in outs["Emissive"]], depth=32)
        if "Discard" in outs and not is_const(outs["Discard"], 0.0):
            results["Alpha"] = b.math("SUBTRACT", 1.0, b.value(outs["Discard"]), depth=33, label="Source discard -> alpha")
        return _finish_group(g, results, connected, OUTPUT_SOCKETS)
    except Exception:
        bpy.data.node_groups.remove(g)
        raise


def _finish_group(g, results, connected, sockets):
    gout = g.nodes.new("NodeGroupOutput")
    gout.location = (3600, 0)
    for name, kind in sockets:
        if name in results:
            g.interface.new_socket(name=name, in_out="OUTPUT", socket_type=kind)
            v = results[name]
            if isinstance(v, (int, float)):
                val = g.nodes.new("ShaderNodeValue")
                val.outputs[0].default_value = float(v)
                v = val.outputs[0]
            g.links.new(v, gout.inputs[name])
            connected.append(name)
    g["unbound_connected_json"] = json.dumps(connected)
    g["unbound_node_count"] = len(g.nodes)
    return g, connected


def make_profile_material(source, profile, group, connected, report_entry):
    import bpy
    mat = source.copy()
    try:
        mat.name = source.name + " | " + profile["Shader"].rsplit("/", 1)[-1]
        mat.use_nodes = True
        nodes, links = mat.node_tree.nodes, mat.node_tree.links
        frame = nodes.new("NodeFrame")
        frame.label = "Original source values / inactive inspection nodes"
        for node in list(nodes):
            if node != frame and node.parent is None:
                node.parent = frame
        frame.location = (-1600, -1400)
        for node in list(nodes):
            if node.type == "OUTPUT_MATERIAL":
                node.is_active_output = False
        gnode = nodes.new("ShaderNodeGroup")
        gnode.node_tree, gnode.location = group, (-300, 300)
        gnode.label = "Compiled source shader (static state)"
        if profile.get("Kind") == "forward_transmittance":
            transparent = nodes.new("ShaderNodeBsdfTransparent")
            transparent.location, transparent.label = (100, 400), "Source transmittance (dual-source target 1)"
            links.new(gnode.outputs["Transmittance"], transparent.inputs["Color"])
            shader = transparent.outputs[0]
            if "Reflectance" in connected:
                glossy = nodes.new("ShaderNodeBsdfAnisotropic") if not hasattr(bpy.types, "ShaderNodeBsdfGlossy") else nodes.new("ShaderNodeBsdfGlossy")
                glossy.location, glossy.label = (100, 200), "Reflection weighted by the source Fresnel term"
                glossy.inputs["Roughness"].default_value = 0.0
                links.new(gnode.outputs["Reflectance"], glossy.inputs["Color"])
                add = nodes.new("ShaderNodeAddShader")
                add.location = (300, 300)
                links.new(transparent.outputs[0], add.inputs[0])
                links.new(glossy.outputs[0], add.inputs[1])
                shader = add.outputs[0]
            if hasattr(mat, "surface_render_method"):
                mat.surface_render_method = "DITHERED"
            out = nodes.new("ShaderNodeOutputMaterial")
            out.is_active_output, out.location = True, (500, 300)
            links.new(shader, out.inputs["Surface"])
            mat["unbound_surface_profile"] = "unbound-compiled-forward-transmittance-v1"
            mat["unbound_surface_key"] = report_entry["Identity"]
            mat["unbound_status"] = "Compiled source glass transmittance, static state"
            mat["unbound_surface_evidence_json"] = canonical(report_entry)
            return mat
        bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location, bsdf.label = (100, 300), "Principled translation of source G-buffer outputs"
        bsdf.inputs["IOR"].default_value = 1.5
        for name in connected:
            links.new(gnode.outputs[name], bsdf.inputs[name])
        if "Emission Color" in connected:
            bsdf.inputs["Emission Strength"].default_value = 1.0
        if "Alpha" in connected and hasattr(mat, "surface_render_method"):
            mat.surface_render_method = "DITHERED"
        out = nodes.new("ShaderNodeOutputMaterial")
        out.is_active_output, out.location = True, (450, 300)
        links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
        mat["unbound_surface_profile"] = "unbound-compiled-gbuffer-v1"
        mat["unbound_surface_key"] = report_entry["Identity"]
        mat["unbound_status"] = "Compiled source shader, static state; Principled translation"
        mat["unbound_surface_evidence_json"] = canonical(report_entry)
        return mat
    except Exception:
        bpy.data.materials.remove(mat)
        raise


# ------------------------------------------------------------------ program/layout entries (profile schema 2)
# Vertex-program constants passed straight to the pixel program, set per wheel instance at runtime.
# Polarity evidence: the pixel programs compute lerp(rear parameter, front parameter, clamp(value)).
VS_CONSTANTS = {("g_facingParam", "x"): "Front", ("g_brakeAndCaliperCustomizeParam", "y"): "Front"}
CONNECTED_OUTPUTS = ("BaseColor", "Metallic", "Smoothness", "Normal", "CoatSmoothness", "CoatNormal", "RT2.x",
                     "Discard", "Transmittance", "Reflectance")


def section_layout(section):
    return [a["Usage"] for a in section.get("VertexAttributes", []) if a["Usage"] != "Unknown"]


def entries_for(profile, layout):
    out = []
    for e in profile.get("Entries", []):
        if layout in e["Layouts"]:
            e.setdefault("Kind", profile.get("Kind", "gbuffer"))
            e.setdefault("Shader", profile["Shader"])
            out.append(e)
    return out


def wheel_facing(obj, assembly_doc):
    """Front flag of the wheel an assembled part belongs to (assembly Wheels[].Facing.Front)."""
    o = obj
    while o is not None and not o.get("wheel_side"):
        o = o.parent
    if o is None or not assembly_doc:
        return None
    wheels = [w for w in assembly_doc.get("Wheels", []) if w.get("Name") == o["wheel_side"]]
    if len(wheels) != 1 or not isinstance(wheels[0].get("Facing"), dict):
        return None
    return bool(wheels[0]["Facing"].get("Front"))


def input_constants(entry, obj, assembly_doc):
    """Per-object values for vertex-constant inputs, or raise if one is unknown."""
    values = {}
    for n in entry["Nodes"]:
        if n["op"] == "input" and n["name"].startswith("VSConst:"):
            name, _, comp = n["name"][8:].partition(".")
            meaning = VS_CONSTANTS.get((name, comp))
            if meaning != "Front":
                raise Unsupported("Unknown per-instance vertex constant " + n["name"])
            front = wheel_facing(obj, assembly_doc)
            if front is None:
                raise Unsupported("Not mounted on an assembled wheel: per-wheel input " + n["name"] + " unknown")
            values[n["name"]] = 1.0 if front else 0.0
    return values


def evaluate_spec(spec, roots, n=4000, seed=11):
    """Numeric evaluation of specialized nodes with shared random leaves (used to compare alternatives)."""
    import zlib
    import numpy as np
    leaves, memo = {}, {}

    def leaf(name):
        # Deterministic per leaf name, independent of traversal order (alternatives must see identical inputs).
        if name not in leaves:
            rng = np.random.default_rng(zlib.crc32(name.encode()) + seed)
            leaves[name] = (np.floor(rng.random(n) * 256) / 255.0 if name.startswith("Color")
                            else rng.uniform(-0.5, 1.5, n))
        return leaves[name]

    def val(v):
        if not isinstance(v, tuple):
            return np.full(n, _f(v))
        i = v[1]
        if i in memo:
            return memo[i]
        rec = spec.nodes[i]
        op = rec["op"]
        with np.errstate(all="ignore"):
            if op in ("input", "view"):
                r = leaf(rec["name"])
            elif op == "param":
                r = leaf("P:%s.%d" % (rec["name"], rec["c"]))
            elif op == "tex":
                co = [val(c) for c in rec["coords"]]
                h = 0.37 * rec["slot"] + sum(c * (3.1 + 1.7 * k) for k, c in enumerate(co))
                r = [0.5 + 0.5 * np.sin(h + 0.7 * k) for k in range(4)]
            elif op == "ch":
                r = val(rec["args"][0])[rec["args"][1]]
            elif op == "frame":
                a = [val(x) for x in rec["args"]]
                cols = [leaf("%s.%s" % (b, "xyz"[rec["k"]])) for b in ("T", "B", "N")]
                r = cols[0] * a[0] + cols[1] * a[1] + cols[2] * a[2]
            else:
                r = _np_op(op, [val(x) for x in rec["args"]], rec)
        memo[i] = r
        return r
    out = {}
    for k, v in roots.items():
        for j, x in enumerate(v if isinstance(v, list) else [v]):
            out["%s%d" % (k, j)] = val(x)
    return out


def _np_op(op, a, rec):
    import numpy as np
    if op in ("add", "iadd"): return a[0] + a[1]
    if op in ("sub", "isub"): return a[0] - a[1]
    if op in ("mul", "imul"): return a[0] * a[1]
    if op == "div": return a[0] / a[1]
    if op == "neg": return -a[0]
    if op in ("max", "binop37", "binop39"): return np.maximum(a[0], a[1])
    if op in ("min", "binop38", "binop40"): return np.minimum(a[0], a[1])
    if op == "abs": return np.abs(a[0])
    if op == "saturate": return np.clip(a[0], 0, 1)
    if op == "sqrt": return np.sqrt(a[0])
    if op == "rsqrt": return 1 / np.sqrt(a[0])
    if op == "exp2": return np.exp2(a[0])
    if op == "log2": return np.log2(a[0])
    if op == "frac": return a[0] - np.floor(a[0])
    if op == "floor": return np.floor(a[0])
    if op == "ceil": return np.ceil(a[0])
    if op in ("trunc", "fptoui_i32", "fptosi_i32"): return np.trunc(np.nan_to_num(a[0]))
    if op == "round_ne": return np.round(a[0])
    if op in ("sin", "cos", "tan"): return getattr(np, op)(a[0])
    if op in ("fmod", "isrem"): return np.fmod(a[0], a[1])
    if op == "select": return np.where(a[0] > 0.5, a[1], a[2])
    if op == "and": return a[0] * a[1]
    if op == "or": return np.maximum(a[0], a[1])
    if op == "not": return 1 - a[0]
    if op in ("uitofp_float", "sitofp_float", "zext_i32"): return a[0]
    if op.startswith(("fcmp_", "icmp_")):
        x, y = a
        p = op[5:]
        r = {"olt": x < y, "ult": x < y, "slt": x < y, "ogt": x > y, "ugt": x > y, "sgt": x > y,
             "ole": x <= y, "ule": x <= y, "sle": x <= y, "oge": x >= y, "uge": x >= y, "sge": x >= y,
             "oeq": x == y, "ueq": x == y, "one": x != y, "une": x != y, "eq": x == y, "ne": x != y}[p]
        return r.astype(float)
    if op == "ishl": return a[0] * 2.0 ** a[1]
    if op == "ilshr": return np.floor(a[0] / 2.0 ** a[1])
    if op == "iand":
        m = int(a[1][0]) & 0xffffffff
        return np.mod(a[0], m + 1) if m & (m + 1) == 0 else a[0] - np.mod(a[0], 2)
    if op == "lookup":
        t = np.array(rec["table"])
        return t[np.clip(np.nan_to_num(a[0]).astype(int), 0, len(t) - 1)]
    raise Unsupported("No numeric evaluation for " + op)


def choose_entry(candidates, plans):
    """Alternatives for one layout must agree after specialization; a single bounded difference is noted."""
    import numpy as np
    primary = plans[0]
    notes = []
    keys = [k for k in CONNECTED_OUTPUTS if k in primary["outs"]]
    ref = evaluate_spec(primary["spec"], {k: primary["outs"][k] for k in keys})
    for entry, p in zip(candidates[1:], plans[1:]):
        if set(k for k in CONNECTED_OUTPUTS if k in p["outs"]) != set(keys):
            raise Unsupported("Alternative programs expose different outputs for this vertex layout")
        alt = evaluate_spec(p["spec"], {k: p["outs"][k] for k in keys})
        diff = {}
        for k, a in ref.items():
            b = alt[k]
            ok = np.isfinite(a) & np.isfinite(b)
            d = float(np.max(np.abs(a[ok] - b[ok]))) if ok.any() else 0.0
            if d > 1e-4:
                diff[k.rstrip("0123456789")] = max(d, diff.get(k.rstrip("0123456789"), 0.0))
        if not diff:
            continue
        coat_only = set(diff) <= {"CoatSmoothness", "RT2.x"}
        if (len(diff) == 1 or coat_only) and max(diff.values()) <= 0.1 + 1e-6:
            notes.append({"AlternateProgram": entry["Programs"][0], "Outputs": sorted(diff),
                          "MaxDifference": max(diff.values()),
                          "Status": "bounded difference between permutations (one coat-finish constant, 0.7 vs 0.8); "
                                    "entry with most solutions used"})
        else:
            raise Unsupported("Permutations disagree for this vertex layout (%s); selection key unknown"
                             % ", ".join(sorted(diff)))
    return notes
