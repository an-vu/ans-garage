"""Non-destructive, source-backed vehicle assembly for the existing FBX importer.

Only imported object copies and collection memberships change. Mesh datablocks,
UVs, color attributes, split normals, groups and the original hierarchy are reused.
"""
import json
import math
import re
from collections import defaultdict
from pathlib import Path


def category(item):
    """Presentation labels use actual item type/location, never compatibility guesses."""
    kind, location = item["Type"], item.get("Location", "")
    end = "Front" if location == "ItemPosition_Front" else "Rear" if location == "ItemPosition_Rear" else ""
    names = {"BumperItemData": end + " Bumper", "FendersItemData": end + " Fenders",
             "LightsItemData": "Headlights" if end == "Front" else "Taillights" if end == "Rear" else "Lights",
             "SideSkirtsItemData": "Side Skirts", "WingMirrorsItemData": "Mirrors",
             "HoodItemData": "Hood", "TrunkLidItemData": "Boot", "SpoilerItemData": "Spoiler",
             "SplitterItemData": "Front Splitter", "DiffuserItemData": "Rear Diffuser",
             "ExhaustItemData": "Exhaust", "CanardsItemData": end + " Canards"}
    return names.get(kind, re.sub(r"(?<!^)(?=[A-Z])", " ", kind.removesuffix("ItemData"))).strip()


def option_name(item, permutation):
    name = item["Asset"].rsplit("/", 1)[-1]
    match = re.search(r"_(set[^_]+(?:_.*)?)$", name, re.I)
    label = "Stock" if item.get("Default") else (match.group(1).replace("_", " ").title() if match else name)
    if permutation:
        label += " / Source configuration " + str(permutation + 1)
    return label


def matrix_from_basis(values):
    from mathutils import Matrix
    if len(values) != 12 or not all(math.isfinite(x) for x in values):
        raise ValueError("Invalid authored transform")
    return Matrix(((values[0], values[3], values[6], values[9]),
                   (values[1], values[4], values[7], values[10]),
                   (values[2], values[5], values[8], values[11]), (0, 0, 0, 1)))


def _all_collections(root):
    yield root
    for child in root.children:
        yield from _all_collections(child)


def set_variant(root, group, option):
    """Switch complete item permutations without touching mesh or transform data."""
    _apply_selections(root, {group: option})
    if root.get("unbound_presets_json"):
        root["active_source_preset"] = current_preset(root)


def current_preset(root):
    """Describe actual collection choices, rather than the last preset button."""
    selected = {}
    for c in _all_collections(root):
        if "unbound_option" in c and not c.hide_viewport:
            group = c["unbound_group"]
            if group in selected:
                return "Custom"
            selected[group] = c["unbound_option"]
    for name, choices in json.loads(root.get("unbound_presets_json", "{}")).items():
        if choices == selected:
            return name
    return "Custom"


def _apply_selections(root, selections):
    # Validate the complete preset before changing visibility. Recompute duplicate
    # suppression once after every group is in its final state.
    collections = list(_all_collections(root))
    pending = []
    for group, option in selections.items():
        choices = [c for c in collections if c.get("unbound_group") == group and "unbound_option" in c]
        if not any(c["unbound_option"] == option for c in choices):
            raise ValueError("Unknown assembly variant for " + group + ": " + str(option))
        pending.extend((c, c["unbound_option"] != option) for c in choices)
    for collection, hidden in pending:
        collection.hide_viewport = collection.hide_render = hidden
    _suppress_duplicates(root)


def _suppress_duplicates(root):
    import bpy
    # Only identical source + complete placement may be suppressed. Intersection
    # of bounding boxes alone is NOT evidence that different car parts are duplicates.
    seen = set()
    count = 0
    pending, issues = [], []
    def walk(c, visible):
        nonlocal count
        visible = visible and not c.hide_viewport
        if "unbound_instance_key" in c:
            key = c["unbound_instance_key"]
            duplicate = visible and key in seen
            # Blender invalidates its cached recursive collection object iterator
            # when hide_set/hide_render changes visibility. Retain actual object
            # references BEFORE any visibility writes; otherwise later iterator
            # entries can become None after reopening a .blend.
            for o in tuple(c.all_objects):
                if o is None:
                    issues.append({"Collection": c.name, "Issue": "Missing object reference during visibility snapshot"})
                else:
                    pending.append((o, duplicate))
            if duplicate:
                count += 1
            elif visible:
                seen.add(key)
        for sub in tuple(c.children):
            walk(sub, visible)
    walk(root, True)
    view_layer = bpy.context.view_layer
    for obj, duplicate in pending:
        # Excluded layer collections have no object Base in this view layer.
        # Their exclusion stays intact; render visibility can still be updated.
        if view_layer.objects.get(obj.name) == obj:
            obj.hide_set(duplicate, view_layer=view_layer)
        obj.hide_render = duplicate
    root["suppressed_exact_duplicate_instances"] = count
    root["unbound_variant_issues_json"] = json.dumps(issues)


def apply_preset(root, preset):
    spec = json.loads(root["unbound_presets_json"])
    if preset not in spec:
        raise ValueError("Unknown source preset")
    _apply_selections(root, spec[preset])
    root["active_source_preset"] = preset


def assemble_existing(manifest_path):
    import bpy
    from mathutils import Matrix
    path = Path(manifest_path).resolve()
    assembly_path = path.with_name("assembly.json")
    data = json.loads(assembly_path.read_text(encoding="utf-8-sig"))
    manifest = json.loads(path.read_text(encoding="utf-8-sig"))
    if data.get("Schema") != 1 or manifest.get("Schema") != 1:
        raise ValueError("Unsupported assembly/geometry manifest schema")
    if data.get("Status") not in ("completed", "completed_with_issues"):
        raise ValueError("Assembly extraction is incomplete")
    if any(c.get("unbound_assembly_path") == str(assembly_path) for c in bpy.data.collections):
        raise ValueError("This assembly is already present. Use the variant controls; no duplicate assembly was created.")
    records = {m["Id"]: m for m in manifest["Meshes"] if m["Status"] == "exported"}
    templates = defaultdict(list)
    for o in bpy.context.scene.objects:
        key = o.get("unbound_mesh_id")
        if key in records and not o.get("unbound_assembled"):
            templates[key].append(o)
    if data.get("BodyMeshId") not in templates:
        raise ValueError("Import the vehicle's manifest.json first; the body mesh is missing.")
    if len(data["Wheels"]) != 4 or len({w["Name"] for w in data["Wheels"]}) != 4:
        raise ValueError("Four unique authored wheel links are required; no placement will be invented.")
    # Validate matrices, mesh coverage and input files before creating collections.
    for w in data["Wheels"]:
        matrix_from_basis(w["Transform"])
    missing = sorted({u["MeshId"] for u in data["MeshUses"]} - templates.keys())
    if missing:
        raise ValueError("Missing assembly geometry: import the updated manifest, including shared tires/brakes. " + ", ".join(missing))
    nodes = {n["Id"]: n for n in data["Nodes"]}
    uses = defaultdict(list)
    for use in data["MeshUses"]:
        uses[use["BlueprintGuid"]].append(use)
    material_path = path.with_name("materials.json")
    material_data = json.loads(material_path.read_text(encoding="utf-8-sig")) if material_path.exists() else {"Meshes": []}
    mats = {m["MeshId"]: m for m in material_data["Meshes"]}
    bpy.context.view_layer.update()
    # Exact conversion inherited from this native FBX's Blender root, avoiding a
    # separately guessed coordinate system. Rigid wheel roots carry FBX Y-up conversion.
    front_rim_item = next(i for i in data["Items"] if i["Type"] == "RimsItemData" and i["Default"])
    rim_use = uses[front_rim_item["Permutations"][0]["Meshes"][0]["BlueprintGuid"]][0]
    sample = templates[rim_use["MeshId"]]
    sample_roots = [o for o in sample if o.parent not in sample]
    if len(sample_roots) != 1:
        raise ValueError("Ambiguous FBX conversion root; assembly not guessed.")
    conversion = sample_roots[0].matrix_world.copy()
    if conversion.translation.length > 1e-5 or any(abs(s-1) > 1e-4 for s in conversion.to_scale()):
        raise ValueError("FBX root conversion has unexpected translation/scale.")
    inverse = conversion.inverted()

    diagnostics = []
    def col(label, parent):
        c = bpy.data.collections.new(label)
        parent.children.link(c)
        return c
    name = data["Vehicle"]["Asset"].rsplit("/", 1)[-1]
    # Human-readable title is cosmetic; the exact vehicle identity is retained.
    name = re.sub(r"^car_", "", name, flags=re.I).replace("_", " ").title()
    root = col(name, bpy.context.scene.collection)
    root["fbx_to_blender_matrix"] = json.dumps([list(r) for r in conversion])
    root["unbound_assembly_path"] = str(assembly_path)
    root["unbound_manifest_path"] = str(path)
    root["vehicle_asset"] = data["Vehicle"]["Asset"]
    root["placement_status"] = "Authored rest pose; runtime loaded suspension is not simulated."
    root["variant_policy"] = "Exact item memberships; source permutation 1 is the preview default. Restriction/offset runtime evaluation is unresolved."
    library = col("Source geometry (preserved)", root)
    # Rehome originals intact, rather than editing/deleting their geometry.
    for meshid, objects in templates.items():
        source = col(records[meshid]["Asset"].rsplit("/", 1)[-1], library)
        source["unbound_mesh_id"] = meshid
        for o in objects:
            source.objects.link(o)
            for old in list(o.users_collection):
                if old != source:
                    old.objects.unlink(o)
    # Unlink now-empty legacy hierarchy from this scene; it remains a datablock.
    for old in list(bpy.context.scene.collection.children):
        if old != root and old.get("manifest") and not old.all_objects:
            bpy.context.scene.collection.children.unlink(old)
    bpy.context.view_layer.update()
    layer_root = bpy.context.view_layer.layer_collection.children[root.name]
    layer_root.children[library.name].exclude = True

    def empty(label, collection, parent=None, transform=None):
        o = bpy.data.objects.new(label, None)
        collection.objects.link(o)
        o.empty_display_type = "PLAIN_AXES"
        o.empty_display_size = 0.08
        if parent:
            o.parent = parent
        if transform is not None:
            o.matrix_basis = transform
        o["unbound_assembled"] = True
        return o

    def attach_metadata(clone, meshid):
        original = re.sub(r"\.\d{3}$", "", clone["unbound_original_name"])
        sections = mats.get(meshid, {}).get("Sections", [])
        matches = [s for s in sections if s["Renderable"] and s["Name"] == original]
        if not matches:
            diagnostics.append("No unambiguous section name for " + records[meshid]["Asset"] + "/" + original)
        clone["unbound_section_candidates_json"] = json.dumps([s["SectionIndex"] for s in matches])
        slots = sorted({s["MaterialSlot"] for s in matches})
        clone["unbound_material_slot_indices_json"] = json.dumps(slots)
        clone["unbound_materials_path"] = str(material_path)
        clone["unbound_material_assignment_status"] = "exact_slot" if len(slots) == 1 else "unresolved_or_multiple"
        clone["unbound_source_asset"] = records[meshid]["Asset"]
        clone["unbound_file_guid"] = records[meshid]["FileGuid"]
        clone["unbound_class_guid"] = records[meshid]["ClassGuid"]

    def instance(meshid, collection, label, parent=None, local=None, body=False):
        # Object copies share immutable geometry. Armature targets are remapped.
        originals = templates[meshid]
        inst = col(label, collection)
        transform = local if local is not None else Matrix.Identity(4)
        inst["unbound_instance_key"] = json.dumps([meshid, [round(x, 8) for row in transform for x in row],
                                                    parent.get("wheel_side") if parent else None])
        mapping = {}
        for source in originals:
            clone = source.copy()
            inst.objects.link(clone)
            mapping[source] = clone
            clone["unbound_assembled"] = True
            clone["unbound_original_name"] = source.name
            clone["unbound_baseline_matrix_world"] = json.dumps([list(r) for r in source.matrix_world])
            if clone.type == "MESH":
                attach_metadata(clone, meshid)
        for source, clone in mapping.items():
            clone.parent = mapping.get(source.parent, parent)
            if source.parent in mapping:
                clone.matrix_parent_inverse = source.matrix_parent_inverse.copy()
                clone.matrix_basis = source.matrix_basis.copy()
            else:
                clone.matrix_parent_inverse = Matrix.Identity(4)
                clone.matrix_basis = transform @ source.matrix_world
            for modifier in clone.modifiers:
                if modifier.type == "ARMATURE" and modifier.object in mapping:
                    modifier.object = mapping[modifier.object]
        if body:
            subgroups = {}
            for o in mapping.values():
                if o.type != "MESH":
                    continue
                rawname = o["unbound_original_name"].lower()
                group = "Windows" if "glass_window" in rawname else "Interior" if "interior" in rawname else "Body panels"
                subgroups.setdefault(group, None)
                if subgroups[group] is None:
                    subgroups[group] = col(group, inst)
                subgroups[group].objects.link(o)
                inst.objects.unlink(o)
        else:
            plates = [o for o in mapping.values() if o.type == "MESH" and "licenseplate" in o["unbound_original_name"].lower()]
            if plates:
                plate_col = col("License Plate", inst)
                for o in plates:
                    plate_col.objects.link(o)
                    inst.objects.unlink(o)
        return inst

    body = col("Body", root)
    instance(data["BodyMeshId"], body, "Original body assembly", body=True)
    wheel_root = col("Wheels", root)
    wheel_controls = {}
    tire_config = nodes[data["TireConfig"]]["Raw"] if data.get("TireConfig") in nodes else {}
    for w in data["Wheels"]:
        c = col(w["Name"], wheel_root)
        authored = matrix_from_basis(w["Transform"])
        rest = empty(w["Name"] + " | Rest position", c, transform=conversion @ authored @ inverse)
        rest["source_wheel_node"] = w["WheelComponent"]
        rest["source_transform_json"] = json.dumps(w["Transform"])
        suspension = empty(w["Name"] + " | Suspension", c, rest)
        steering = empty(w["Name"] + " | Steering", c, suspension)
        spin = empty(w["Name"] + " | Rotation", c, steering)
        for o in (rest, suspension, steering, spin):
            o["wheel_side"] = w["Name"]
        spin["animation_axis"] = "Local X axle; rest-space axes converted from FBX"
        steering["animation_axis"] = "Local Blender Z (authored Y)"
        suspension["animation_axis"] = "Local Blender Z (authored Y)"
        wheel_controls[w["Name"]] = (c, steering, spin)
    used = {data["BodyMeshId"]}
    # Source wheel declarations are explicit; runtime resize/deformation is tracked separately.
    for item in data["Items"]:
        if item["Type"] not in ("RimsItemData", "TiresItemData", "BrakeDiscsItemData", "CalipersItemData") or not item["Default"]:
            continue
        if not item["Permutations"]:
            continue
        for desc in item["Permutations"][0]["Meshes"]:
            facing = desc.get("Facing")
            if not facing or facing["Name"] not in wheel_controls:
                diagnostics.append("Unresolved wheel facing: " + item["Asset"])
                continue
            c, steering, spin = wheel_controls[facing["Name"]]
            rotation = Matrix.Rotation(math.pi, 4, "Y") if desc["Rotate"] else Matrix.Identity(4)
            scaling = Matrix.Identity(4)
            status = "Original authored rim/part dimensions retained; runtime shader resize not applied."
            if item["Type"] == "TiresItemData":
                info = next((i for i in (item.get("TireMeshInfos") or []) if any(m["MeshGuid"] == desc["BlueprintGuid"] for m in i["Meshes"])), None)
                axle = "Front" if facing["Front"] else "Rear"
                outer = tire_config.get("Diameter" + axle)
                width = tire_config.get("SectionWidth" + axle)
                if info and outer and width and info["OuterDiameter"] > 0 and info["Width"] > 0:
                    # Reversible object scale from declared dimensions. No mesh edit;
                    # no claim to reproduce Frostbite's inner/outer-radius shader.
                    scaling = Matrix.Diagonal((width / 1000.0 / info["Width"], outer / info["OuterDiameter"], outer / info["OuterDiameter"], 1))
                    status = "Experimental dimensional fit: source width/outer diameter to vehicle tire config; inner bead/shader deformation unverified."
                else:
                    status = "Tire dimensions unresolved: source scale preserved."
                    diagnostics.append(status + " " + item["Asset"])
            kind = {"RimsItemData": "Rim", "TiresItemData": "Tire", "BrakeDiscsItemData": "Brake Disc", "CalipersItemData": "Caliper"}[item["Type"]]
            parent = steering if item["Type"] == "CalipersItemData" else spin
            for use in uses[desc["BlueprintGuid"]]:
                proxy = Matrix.Identity(4)
                for matrix in use["TransformChain"]:
                    proxy = proxy @ matrix_from_basis(matrix)
                inst = instance(use["MeshId"], c, kind, parent, conversion @ rotation @ scaling @ proxy @ inverse)
                inst["source_item"] = item["Asset"]
                inst["source_rotate_flag"] = desc["Rotate"]
                inst["dimension_status"] = status
                inst["source_item_json"] = json.dumps(item["Raw"])
                used.add(use["MeshId"])
    defaults, item_choices, group_collections = {}, {}, {}
    for item in data["Items"]:
        if item["Type"] in ("RimsItemData", "TiresItemData", "BrakeDiscsItemData", "CalipersItemData") or not item["Permutations"]:
            continue
        group = category(item)
        if group not in group_collections:
            group_collections[group] = col(group, root)
        parent_col = group_collections[group]
        if not parent_col.get("unbound_choice_group"):
            parent_col["unbound_choice_group"] = group
            parent_col["show_variants"] = False
            none = col(group + " | None", parent_col)
            none["unbound_group"], none["unbound_option"] = group, "none"
        for index, permutation in enumerate(item["Permutations"]):
            if permutation.get("Deprecated"):
                continue
            option = item["Node"] + "/" + str(index)
            variant = col(group + " | " + option_name(item, index), parent_col)
            variant["unbound_group"], variant["unbound_option"] = group, option
            variant["unbound_item"] = item["Asset"]
            variant["source_permutation_json"] = json.dumps(permutation)
            variant["compatibility_status"] = "Source membership preserved; runtime restrictions and permutation offsets not evaluated."
            if item["Default"] and index == 0:
                defaults[group] = option
            if index == 0:
                item_choices[item["Asset"].lower()] = (group, option)
            local_seen = set()
            for desc in permutation["Meshes"]:
                if desc.get("Facing") or desc["Rotate"]:
                    diagnostics.append("Non-wheel tagged/rotated item needs explicit placement: " + item["Asset"])
                    continue
                for use in uses.get(desc["BlueprintGuid"], []):
                    # Body parts already align; preserve their exact existing world matrices.
                    key = use["MeshId"]
                    if key in local_seen:
                        continue
                    local_seen.add(key)
                    label = records[key]["Asset"].rsplit("/", 1)[-1]
                    label = re.sub(r"^car_.*?_\d{4}_", "", label).removesuffix("_mesh").replace("_", " ").title()
                    inst = instance(key, variant, label)
                    inst["source_blueprint_guid"] = desc["BlueprintGuid"]
                    used.add(key)
            variant.hide_viewport = variant.hide_render = defaults.get(group) != option
    for group_col in root.children:
        group = group_col.get("unbound_choice_group")
        if group:
            defaults.setdefault(group, "none")
            set_variant(root, group, defaults[group])
    presets = {"Stock": defaults}
    for preset in data.get("Presets", []):
        choices = dict(defaults)
        missing_items = []
        for p in preset["SubItems"]:
            match = item_choices.get((p.get("Asset") or "").lower())
            if match:
                choices[match[0]] = match[1]
            else:
                missing_items.append(p.get("Asset"))
        label = preset["Asset"].rsplit("/", 1)[-1]
        presets[label] = choices
        if missing_items:
            diagnostics.append("Unresolved preset items: " + str(missing_items))
    root["unbound_presets_json"] = json.dumps(presets)
    root["active_source_preset"] = "Stock"
    leftovers = col("Unassigned source parts (review)", root)
    leftovers.hide_viewport = leftovers.hide_render = True
    for meshid in sorted(set(templates) - used):
        instance(meshid, leftovers, records[meshid]["Asset"].rsplit("/", 1)[-1])
        diagnostics.append("No selected blueprint/item placement: " + records[meshid]["Asset"])
    _suppress_duplicates(root)
    diagnostics += [
        "Right-side Rotate flag interpreted as a half turn about source Y; outward rim facing checked, runtime implementation unavailable.",
        "Tire fitting uses object scale from declared width/outer diameter; exact inner bead and shader deformation remain experimental.",
        "Rim and brake shader sizing, caliper runtime offsets, loaded suspension and camber are not reconstructed.",
        "Variant collections preserve item permutations; runtime restrictions/offsets are recorded, not guessed.",
        "Material IDs are custom metadata; no placeholder materials or shaders were generated."
    ]
    root["diagnostics_json"] = json.dumps(diagnostics)
    text = bpy.data.texts.new("Unbound assembly report")
    text.write("Authored vehicle assembly\n" + "\n".join(diagnostics))
    bpy.context.view_layer.update()
    return root, diagnostics
