"""Collect solutions/programs for every shader referenced by the export (read-only)."""
import importlib.util, json, struct, sys, uuid
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]).parent))
from read_unbound_shaderdb import name_hash
p = json.loads(Path(sys.argv[2]).read_text())[0]
doc = json.loads(Path(sys.argv[3]).read_text(encoding="utf-8-sig"))
shaders = sorted({n["Asset"] for n in doc["Nodes"] if n["Type"] == "ShaderGraph"})
byhash = {s["Hash"]: s for s in p["Shaders"]}
result = {}
allbc = set()
for name in shaders:
    t = byhash.get(name_hash(name))
    if not t:
        print("NOT IN DB", name); continue
    recs = []
    for i in t["Solutions"]:
        s = p["Solutions"][i]
        if s["PS"] == 0xffffffffffffffff: continue
        ps, vs = p["Permutations"]["Pixel"][s["PS"]], p["Permutations"]["Vertex"][s["VS"]]
        recs.append({"SolutionIndex": i, "Flags": s["State"], "StateHash": s["StateHash"], "PSIndex": s["PS"], "VSIndex": s["VS"],
                     "PS": ps["Bytecode"], "VS": vs["Bytecode"], "PSConstants": s["PSConstants"], "VSConstants": s["VSConstants"],
                     "Declaration": p["Declarations"][p["DeclarationIndices"][s["VS"]]]})
        allbc.update((ps["Bytecode"], vs["Bytecode"]))
    result[name] = {"Hash": t["Hash"], "Offset": t["Offset"], "Textures": t["Textures"],
                    "Streaming": [[str(uuid.UUID(bytes_le=struct.pack("<4I", *e[:4])))] + list(e[4:]) for e in t["ExternalTextures"]],
                    "Solutions": recs}
    print(f"{name}: {len(recs)} solutions, PS {len({r['PS'] for r in recs})}, VS {len({r['VS'] for r in recs})}")
Path("vehicle-shader-programs.json").write_text(json.dumps(result, indent=1))
Path("bytecode-filter.txt").write_text("|".join(sorted(allbc)))
print("total bytecodes", len(allbc))
