"""Extract mip-0 slices of a Frostbite 2D texture array (raw resource, mip-major layout verified) to PNG."""
import hashlib, json, sys
from pathlib import Path
import numpy as np
from PIL import Image
src_dir, dst_root = Path(sys.argv[1]), Path(sys.argv[2])
rec = json.loads((src_dir / "textures.json").read_text(encoding="utf-8-sig"))["Textures"][0]
assert rec["Format"] == "R8G8B8A8_UNORM" and rec["TextureType"] == "TT_2dArray"
W, H, S = rec["Width"], rec["Height"], rec["Depth"]
raw = np.fromfile(src_dir / rec["RawData"], dtype=np.uint8)
assert hashlib.sha256(raw.tobytes()).hexdigest() == rec["RawSha256"]
assert len(raw) == sum((W >> i) * (H >> i) * 4 for i in range(rec["MipCount"])) * S
folder = dst_root / "textures" / rec["ResourceId"]
folder.mkdir(parents=True, exist_ok=True)
slices = []
for i in range(S):
    a = raw[i * W * H * 4:(i + 1) * W * H * 4].reshape(H, W, 4)
    path = folder / ("%s_slice%02d.png" % (Path(rec["Path"]).stem, i))
    Image.fromarray(a, "RGBA").save(path)
    slices.append({"Path": str(path.relative_to(dst_root)).replace("\\", "/"), "Sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
index = dst_root / "textures.json"
doc = json.loads(index.read_text(encoding="utf-8-sig"))
doc["Textures"] = [t for t in doc["Textures"] if t.get("ResourceId") != rec["ResourceId"]]
doc["Textures"].append({**{k: rec[k] for k in ("ResourceId", "Aliases", "Format", "ColorSpace", "TextureType", "Width", "Height", "Depth", "RawSha256")},
                        "Path": slices[0]["Path"], "Slices": slices,
                        "Derivation": "Mip 0 of each array slice taken from the raw resource; mip-major layout verified "
                                      "(mip 1 of each slice matches a 2x2 box filter of its mip 0). Lossless PNG, values unchanged."})
index.write_text(json.dumps(doc, indent=1))
print("slices", len(slices))
