"""For each VS paired with a PS: map PS interpolant (row, col) -> direct VS input element/component, or 'computed'."""
import json, re, sys
from collections import defaultdict
from pathlib import Path
progs = json.loads(Path("vehicle-shader-programs.json").read_text())
FMT = {3: "Float3", 4: "Float4", 6: "Half2", 8: "Half4", 13: "UByte4N", 19: "Short2N", 23: "UShort4", 25: "UShort4N"}
def routing(vs):
    text = Path("asm/%s.asm" % vs).read_text()
    defs = {}
    for line in text.splitlines():
        m = re.match(r"\s+(%\d+) = (.*?)(\s+;.*)?$", line)
        if m: defs[m.group(1)] = m.group(2)
    out = {}
    for m in re.finditer(r"storeOutput\.f32\(i32 5, i32 1, i32 (\d+), i8 (\d), float (\S+)\)", text):
        row, col, v = int(m.group(1)), int(m.group(2)), m.group(3)
        d = defs.get(v, v)
        li = re.match(r"call float @dx\.op\.loadInput\.f32\(i32 4, i32 (\d+), i32 0, i8 (\d)", d)
        out[(row, col)] = ("E%d.%s" % (int(li.group(1)), "xyzw"[int(li.group(2))])) if li else ("const " + v if not v.startswith("%") else "computed")
    return out
shader, ps = sys.argv[1], sys.argv[2]
combos = defaultdict(list)
for s in progs[shader]["Solutions"]:
    if s["PS"] == ps:
        decl = tuple(FMT.get(d[0], d[0]) for d in s["Declaration"])
        combos[(s["VS"], decl)].append(s["SolutionIndex"])
for (vs, decl), sols in combos.items():
    r = routing(vs)
    print(vs[:8], decl)
    print("    ", {"%d.%s" % (k[0], "xyzw"[k[1]]): v for k, v in sorted(r.items()) if not v.startswith("computed")})
