"""Backward def-use slice for storeOutput(sig,row,col) in a DXIL listing."""
import re, sys
from pathlib import Path
text = Path(sys.argv[1]).read_text()
defs = {}
for line in text.splitlines():
    m = re.match(r"\s+(%\d+) = (.*?)(\s+;.*)?$", line)
    if m: defs[m.group(1)] = m.group(2)
def show(v, depth, seen):
    if v in seen or depth > int(sys.argv[3]): return
    seen.add(v)
    d = defs.get(v, "?")
    print("  " * depth + v + " = " + d[:200])
    if "phi" in d.split(" ")[0] or "loadInput" in d or "cbufferLoad" in d: 
        if "phi" not in d.split(" ")[0]: return
    for u in re.findall(r"%\d+", d):
        show(u, depth + 1, seen)
for spec in sys.argv[2].split(";"):
    sig, col = spec.split(",")
    for line in text.splitlines():
        m = re.search(r"storeOutput\.f32\(i32 5, i32 %s, i32 0, i8 %s, float (\S+)\)" % (sig, col), line)
        if m:
            print("OUTPUT sig %s col %s <- %s" % (sig, col, m.group(1)))
            show(m.group(1), 1, set())
