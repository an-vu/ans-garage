import json, re, sys
from collections import defaultdict
from pathlib import Path
progs = json.loads(Path("vehicle-shader-programs.json").read_text())
info = {}
for f in Path("asm").glob("*.asm"):
    t = f.read_text()
    head = t.split("define void @main")[0]
    if "Pixel Shader" not in head:
        continue
    outs = len(re.findall(r"^; SV_Target\s+\d+\s+xyzw", head, re.M))
    tex = len(re.findall(r"^;\s+texture ", head, re.M))
    disc = "dx.op.discard" in t
    info[f.stem] = (outs, tex, disc, len(t.splitlines()))
for sh in sys.argv[1:] or progs:
    rec = progs[sh]
    seen = defaultdict(int)
    for s in rec["Solutions"]:
        seen[s["PS"]] += 1
    print(sh)
    for ps, n in seen.items():
        print("   ", ps, "sol", n, "targets/tex/discard/lines", info.get(ps))
