"""Survey resolved source material states per shader (read-only)."""
import importlib.util, json, sys
from collections import Counter, defaultdict
from pathlib import Path
spec = importlib.util.spec_from_file_location("um", sys.argv[1])
um = importlib.util.module_from_spec(spec); spec.loader.exec_module(um)
doc = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8-sig"))
r = um.Resolver(doc)
by = defaultdict(lambda: {"slots": 0, "tex": Counter(), "vec": defaultdict(Counter), "bool": Counter(), "cond": Counter(), "fmt": Counter()})
for mesh in doc["Meshes"]:
    for slot in mesh["Slots"]:
        try:
            st, roots, status = r.choose_root(mesh, slot)
        except Exception as e:
            print("ERR", mesh["MeshId"], slot["Index"], e); continue
        sh = (st["Shader"] or {}).get("Asset", "NONE").rsplit("/", 1)[-1]
        b = by[sh]; b["slots"] += 1
        for t in st["TextureBindings"]:
            b["tex"][t["Parameter"]] += 1
            b["fmt"][(t["Parameter"], t.get("Format"), t.get("ColorSpace"))] += 1
        for k, p in st["Parameters"]["VectorParameters"].items():
            v = p.get("Value", {})
            b["vec"][um.plain(p["ParameterName"])][tuple(round(v.get(c, 0), 4) for c in "xyzw")] += 1
        for k in st["Parameters"]["BoolParameters"]:
            b["bool"][k] += 1
        for k in st["Parameters"]["ConditionalParameters"]:
            b["cond"][k[:80]] += 1
want = sys.argv[3:] or list(by)
for sh in sorted(by, key=lambda s: -by[s]["slots"]):
    b = by[sh]
    print(f"\n=== {sh}: {b['slots']} slots")
    if sh not in want and want != list(by): continue
    print(" textures:", dict(b["tex"]))
    for k, v in b["fmt"].items(): print("   fmt", k, v)
    for name, vals in b["vec"].items(): print("  vec", name, dict(vals))
    if b["bool"]: print(" bool", dict(b["bool"]))
    if b["cond"]: print(" cond", dict(b["cond"]))
