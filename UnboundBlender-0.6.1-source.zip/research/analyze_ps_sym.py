"""Like analyze_ps.py, but keep named externals symbolic: args ... --unknown=A,B [Name=x,y,z,w]"""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
sys.setrecursionlimit(20000)
import dxil_eval as dx
dx.OPAQUE_LOOPS = True
import analyze_ps as ap
args = [a for a in sys.argv[1:] if not a.startswith("--")]
unknown = next((a.split("=", 1)[1].split(",") for a in sys.argv if a.startswith("--unknown=")), [])
only = next((a.split("=", 1)[1].split(",") for a in sys.argv if a.startswith("--only=")), None)
parsed = json.loads(Path(args[0]).read_text())[0]
programs = json.loads(Path(args[1]).read_text())
ov = {}
for a in args[5:]:
    k, v = a.split("=")
    ov[k] = [float(x) for x in v.split(",")] + [0.0] * (4 - len(v.split(",")))
prog, ev, consts, sol, bind = ap.run(parsed, programs, args[2], args[3], args[4], ov, unknown)
for v in consts["ExternalValues"]:
    if v["Name"] in unknown:
        print("# SYMBOLIC cb%d[%d] = %s" % (bind, v["Index"] - 1 - consts.get("ValueStart", 0), v["Name"]))
roots = [("RT%d.%s" % (k[0], dx.XYZW[k[1]]), v) for k, v in sorted(ev.outputs.items())
         if only is None or "RT%d.%s" % (k[0], dx.XYZW[k[1]]) in only or "RT%d" % k[0] in only]
print(dx.render(roots))
