"""Generalized summary of one vehicle shader record in the parsed v293 DB (read-only)."""
import json, struct, sys, uuid
from collections import Counter
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]).parent))
from read_unbound_shaderdb import name_hash
p = json.loads(Path(sys.argv[2]).read_text())[0]
name = sys.argv[3]
out = Path(sys.argv[4]) if len(sys.argv) > 4 else None
t = next(s for s in p["Shaders"] if s["Hash"] == name_hash(name))
g = lambda e: str(uuid.UUID(bytes_le=struct.pack("<4I", *e[:4])))
print("SHADER", name, "type", t["Type"], "solutions", len(t["Solutions"]))
print("TEXTURES(hash,?,?,f)", t["Textures"])
print("STREAMING")
for e in t["ExternalTextures"]:
    print("  ", g(e), e[4:])
records, combos = [], Counter()
for i in t["Solutions"]:
    s = p["Solutions"][i]
    if s["PS"] == 0xffffffffffffffff:
        continue
    ps, vs = p["Permutations"]["Pixel"][s["PS"]], p["Permutations"]["Vertex"][s["VS"]]
    records.append({"SolutionIndex": i, "Solution": s, "PS": ps, "VS": vs,
                    "PSConstants": p["Constants"][s["PSConstants"]], "VSConstants": p["Constants"][s["VSConstants"]],
                    "Declaration": p["Declarations"][p["DeclarationIndices"][s["VS"]]]})
    combos[(s["Surface"], s["Blend"], ps["Bytecode"])] += 1
print("SURFACE/BLEND/PS", len(combos))
for k, v in sorted(combos.items()): print("  ", k, v)
seen = set()
for r in records:
    if r["PS"]["Bytecode"] in seen: continue
    seen.add(r["PS"]["Bytecode"])
print("UNIQUE PS", len(seen), "UNIQUE VS", len({r["VS"]["Bytecode"] for r in records}))
# External values union across PS constants
vals, texs = {}, {}
for r in records:
    for st in ("PS", "VS"):
        for v in r[st + "Constants"]["ExternalValues"]:
            vals.setdefault(v["Name"], (v["ParameterKey"], v["Value"], v["Type"], v["Width"]))
        for v in r[st + "Constants"]["ExternalTextures"]:
            texs.setdefault(v["Name"], (v["ParameterKey"], v["Type"], v["Flags"], v["Unknown"]))
print("EXTERNAL VALUES", len(vals))
for k, v in sorted(vals.items()): print("  ", k, v)
print("EXTERNAL TEXTURES", len(texs))
for k, v in sorted(texs.items()): print("  ", k, v)
if out: out.write_text(json.dumps(records, indent=1))
