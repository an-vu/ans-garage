param([string]$Mode,[string]$Filter,[string]$Destination)
$ErrorActionPreference='Stop'
$work='<work-root>'
$ed=Join-Path $work 'work\editor'
$fw='C:\Windows\Microsoft.NET\Framework64\v4.0.30319'
$refs=@('FrostyCore.dll','FrostySdk.dll','Newtonsoft.Json.dll') | ForEach-Object { '/r:'+(Join-Path $ed $_) }
$probePlugin='C:\Users\anvu1\Desktop\Murcielago\UnboundBatchExport\plugin'
$refs+='/r:'+(Join-Path $probePlugin 'UnboundBatchExport.dll')
$refs+=@('WPF\PresentationFramework.dll','WPF\WindowsBase.dll','WPF\PresentationCore.dll','System.Xaml.dll','Microsoft.CSharp.dll') | ForEach-Object { '/r:'+(Join-Path $fw $_) }
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
$exe=Join-Path $here 'LocProbe.exe'
& (Join-Path $fw 'csc.exe') /nologo /platform:x64 ('/out:'+$exe) @refs (Join-Path $here 'LocProbe.cs')
if($LASTEXITCODE -ne 0){throw 'compile failed'}
Push-Location $work
try { & $exe 'C:\Users\anvu1\Downloads\Frosty.Editor.1.0.7.v.26.10.12' $probePlugin $ed 'C:\Program Files (x86)\Steam\steamapps\common\Excalibur' $Mode $Filter $Destination } finally { Pop-Location }
if($LASTEXITCODE -ne 0){throw 'probe failed'}
