using FrostySdk.IO;
using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using Frosty.Core;
using FrostySdk;
using FrostySdk.Managers;
using Newtonsoft.Json;
using UnboundBatchExport;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using FrostySdk.Ebx;
using Newtonsoft.Json.Linq;
using System.Runtime.Serialization;
using Frosty.Core.Windows;
class Harness {
class Logger : FrostySdk.Interfaces.ILogger {
public void Log(string text,params object[] args){Console.WriteLine(text,args);}
public void LogWarning(string text,params object[] args){Console.WriteLine(text,args);}
public void LogError(string text,params object[] args){Console.WriteLine(text,args);}
}
static string editor,plugin;
[STAThread]
static int Main(string[] args) {
editor=Path.GetFullPath(args[0]);plugin=Path.GetFullPath(args[1]);
AppDomain.CurrentDomain.AssemblyResolve+=(s,e)=>{
 var name=new AssemblyName(e.Name).Name;
 if(name=="EbxClasses")return Assembly.LoadFrom(Path.Combine(editor,"Profiles","NFSUnboundSDK.dll"));
 foreach(var dir in new[]{plugin,editor,Path.Combine(editor,"Plugins"),Path.Combine(editor,"ThirdParty")}) {
 var p=Path.Combine(dir,name+".dll");if(File.Exists(p))return Assembly.LoadFrom(p);
 }return null;};
try { Run(args);return 0;}catch(Exception ex){Console.WriteLine(ex);return 1;}
}
[MethodImpl(MethodImplOptions.NoInlining)]
static void Run(string[] a) {
 Directory.SetCurrentDirectory(Path.GetFullPath(a[2]));
 ProfilesLibrary.Initialize();if(!ProfilesLibrary.SelectProfile("NeedForSpeedUnbound"))throw new Exception("Profile missing");
 byte[] keys=File.ReadAllBytes(Path.Combine(editor,"nfsunbound.key"));
 var key=new byte[16];Array.Copy(keys,key,16);KeyManager.Instance.AddKey("Key1",key);
 if(keys.Length>=32) {var k=new byte[16];Array.Copy(keys,16,k,0,16);KeyManager.Instance.AddKey("Key2",k);}
 if(keys.Length>=0x4020){var k=new byte[0x4000];Array.Copy(keys,32,k,0,k.Length);KeyManager.Instance.AddKey("Key3",k);}
 Console.WriteLine("Initializing source filesystem");
 var fs=new FileSystemManager(a[3]);foreach(var source in ProfilesLibrary.Sources)fs.AddSource(source.Path,source.SubDirs);fs.Initialize(key);
 var rm=new ResourceManager(fs);rm.Initialize();App.ResourceManager=rm;App.FileSystemManager=fs;
 TypeLibrary.Initialize();
 var am=new AssetManager(fs,rm);App.AssetManager=am;am.Initialize(false);
 Console.WriteLine("Loaded "+am.GetEbxCount()+" EBX assets");

 string mode=a[4], filter=a[5], destination=a[6];
 if(mode=="loc") {
 // Resolve UI string ids through Frosty's NFS localization plugin (read-only).
 // Frosty settings are required by the localization plugin (language). Load a copy of the harness config.
 Frosty.Core.Config.Load(Environment.GetEnvironmentVariable("UNBOUND_FROSTY_CONFIG_COPY"));
 App.Logger=new Logger();
 var asm=Assembly.LoadFrom(Path.Combine(editor,"Plugins","FsLocalizationPlugin.dll"));
 var dbType=asm.GetType("FsLocalizationPlugin.FsLocalizationStringDatabase");
 var db=Activator.CreateInstance(dbType);
 dbType.GetMethod("Initialize").Invoke(db,null);
 var get=dbType.GetMethod("GetString",new[]{typeof(string)});
 var result=new JObject();
 foreach(string id in filter.Split('|')) { try { result[id]=(string)get.Invoke(db,new object[]{id}); } catch(Exception ex){ result[id]="ERROR "+(ex.InnerException??ex).Message; } }
 File.WriteAllText(destination,result.ToString(Formatting.Indented));
 Console.WriteLine("Strings "+result.Count);
 } else if(mode=="list") {
 var rows=am.EnumerateEbx().Where(e=>filter.Split('|').Any(f=>e.Name.IndexOf(f,StringComparison.OrdinalIgnoreCase)>=0 || e.Type.IndexOf(f,StringComparison.OrdinalIgnoreCase)>=0)).Select(e=>new {e.Name,e.Type,Guid=e.Guid.ToString()}).ToArray();
 File.WriteAllText(destination,JsonConvert.SerializeObject(rows,Formatting.Indented));Console.WriteLine("Entries "+rows.Length);
 } else if(mode=="texture") {
 Directory.CreateDirectory(destination);
 var run=new MaterialRun(destination,filter);
 var method=typeof(MaterialRun).GetMethod("ExportTexture",BindingFlags.Instance|BindingFlags.NonPublic);
 foreach(string name in filter.Split('|')) {
 var entry=am.GetEbxEntry(name);if(entry==null)throw new Exception("Texture not found "+name);
 var asset=am.GetEbx(entry);
 var obj=asset.RootObject;
 method.Invoke(run,new object[]{obj,entry.Guid,MaterialRun.ObjectKey(entry.Guid,obj),entry.Name});
 }
 File.WriteAllText(Path.Combine(destination,"textures.json"),run.Document.ToString(Formatting.Indented));
 } else if(mode=="hashes") {
 var hashes=new HashSet<uint>(filter.Split('|').Select(s=>uint.Parse(s)));
 var rows=am.EnumerateEbx().Where(e=>hashes.Contains((uint)FrostySdk.Utils.HashString(e.Name,true))).Select(e=>new {e.Name,e.Type,Hash=(uint)FrostySdk.Utils.HashString(e.Name,true),Guid=e.Guid});
 File.WriteAllText(destination,JsonConvert.SerializeObject(rows,Formatting.Indented));
 } else if(mode=="enums") {
 var sdk=Assembly.LoadFrom(Path.Combine(editor,"Profiles","NFSUnboundSDK.dll"));
 var rows=sdk.GetTypes().Where(t=>t.IsEnum&&filter.Split('|').Contains(t.Name)).Select(t=>new {t.Name,Values=Enum.GetValues(t).Cast<object>().Select(v=>new {Name=v.ToString(),Value=Convert.ToInt64(v)})});
 File.WriteAllText(destination,JsonConvert.SerializeObject(rows,Formatting.Indented));
 } else if(mode=="dump") {
 var result=new JArray();
 foreach(string name in filter.Split('|')) {
 var entry=am.GetEbxEntry(name);if(entry==null) {Console.WriteLine("Not found "+name);continue;}
 var asset=am.GetEbx(entry);
 var objects=new JArray();
 foreach(var o in asset.Objects)objects.Add(Snap(o,0));
 result.Add(new JObject {{"Name",entry.Name},{"Type",entry.Type},{"Guid",entry.Guid.ToString()},{"Objects",objects}});
 }
 File.WriteAllText(destination,result.ToString(Formatting.Indented));
 } else if(mode=="res") {
 var rows=am.EnumerateRes().Where(e=>filter.Split('|').Any(f=>e.Name.IndexOf(f,StringComparison.OrdinalIgnoreCase)>=0 || e.Type.IndexOf(f,StringComparison.OrdinalIgnoreCase)>=0)).Select(e=>new {e.Name,e.Type,e.ResType,e.ResRid}).ToArray();
 File.WriteAllText(destination,JsonConvert.SerializeObject(rows,Formatting.Indented));Console.WriteLine("Resources "+rows.Length);
 } else if(mode=="resdump") {
 Directory.CreateDirectory(destination);
 var result=new JArray();
 foreach(var e in am.EnumerateRes().Where(e=>filter.Split('|').Any(f=>e.Name.IndexOf(f,StringComparison.OrdinalIgnoreCase)>=0))) {
 var path=Path.Combine(destination,"resource_"+result.Count.ToString("D3")+".bin");
 using(var stream=am.GetRes(e))using(var file=File.Create(path))stream.CopyTo(file);
 result.Add(new JObject {{"Name",e.Name},{"Type",e.Type},{"OriginalSize",e.OriginalSize},{"File",Path.GetFileName(path)}});
 }
 File.WriteAllText(Path.Combine(destination,"index.json"),result.ToString(Formatting.Indented));
 Console.WriteLine("Dumped "+result.Count+" resources");
 } else if(mode=="resheader") {
 var result=new JArray();
 foreach(var e in am.EnumerateRes().Where(e=>e.Name.IndexOf(filter,StringComparison.OrdinalIgnoreCase)>=0)) {
 var row=new JObject {{"Name",e.Name},{"Type",e.Type},{"OriginalSize",e.OriginalSize}};
 try {using(var stream=am.GetRes(e)){row["Length"]=stream.Length;var buffer=new byte[64];int count=stream.Read(buffer,0,buffer.Length);row["Header"]=BitConverter.ToString(buffer,0,count);}}
 catch(Exception ex){row["Error"]=ex.GetType().Name+": "+ex.Message;}
 result.Add(row);
 }
 File.WriteAllText(destination,result.ToString(Formatting.Indented));
 } else if(mode=="types") {
 var sdk=Assembly.LoadFrom(Path.Combine(editor,"Profiles","NFSUnboundSDK.dll"));
 var rows=sdk.GetTypes().Where(t=>filter.Split('|').Any(f=>t.Name.IndexOf(f,StringComparison.OrdinalIgnoreCase)>=0)).Select(t=>new {Type=t.FullName,Base=t.BaseType==null?null:t.BaseType.Name,Properties=t.GetProperties().Select(p=>new {p.Name,Type=p.PropertyType.FullName})});
 File.WriteAllText(destination,JsonConvert.SerializeObject(rows,Formatting.Indented));
 }
}
static JToken Snap(object obj,int depth) {
 if(obj==null)return JValue.CreateNull();
 if(depth>14)return new JObject {{"Truncated",obj.GetType().Name}};
 if(obj is PointerRef) {
 var p=(PointerRef)obj;
 var e=p.Type==PointerRefType.External?App.AssetManager.GetEbxEntry(p.External.FileGuid):null;
 return new JObject {{"Kind",p.Type.ToString()},{"Asset",e==null?null:e.Name},{"FileGuid",p.External.FileGuid},{"ClassGuid",p.External.ClassGuid},{"Internal",p.Type==PointerRefType.Internal?GuidOf(p.Internal):null},{"Type",p.Internal==null?null:p.Internal.GetType().Name}};
 }
 if(obj is ResourceRef)return new JValue(((ulong)(ResourceRef)obj).ToString("x16"));
 var t=obj.GetType();
 if(t==typeof(string)||t==typeof(Guid)||t.IsPrimitive||t==typeof(decimal))return JToken.FromObject(obj);
 if(t.IsEnum||t.Name=="CString"||t.Name=="FileRef")return new JValue(obj.ToString());
 if(obj is IEnumerable){var arr=new JArray();int n=0;foreach(var v in (IEnumerable)obj){if(n++>=20000){arr.Add("truncated");break;}arr.Add(Snap(v,depth+1));}return arr;}
 var o=new JObject {{"$type",t.Name}};
 var id=GuidOf(obj);if(id!=null)o["$id"]=id;
 foreach(var p in t.GetProperties().Where(p=>p.GetIndexParameters().Length==0)){try{o[p.Name]=Snap(p.GetValue(obj,null),depth+1);}catch(Exception ex){o[p.Name]="ERROR "+ex.Message;}}
 foreach(var f in t.GetFields()){try{o[f.Name]=Snap(f.GetValue(obj),depth+1);}catch(Exception ex){o[f.Name]="ERROR "+ex.Message;}}
 return o;
}
static string GuidOf(object obj) {
 var m=obj.GetType().GetMethod("GetInstanceGuid",Type.EmptyTypes);if(m==null)return null;
 var g=(AssetClassGuid)m.Invoke(obj,null);return g.IsExported?g.ExportedGuid.ToString():"internal:"+g.InternalId;
}
}

